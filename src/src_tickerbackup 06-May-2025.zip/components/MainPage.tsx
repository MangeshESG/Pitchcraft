import React, { useRef, useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./MainPage.css";
import Modal from "./common/Modal";
import Tabs from "./common/Tabs";
import { getPrompts, createPrompts, deletePrompt } from "../api/axios";
import { useSelector } from "react-redux";
import ReactQuill from "react-quill-new";
import Mail from "./feature/Mail";

import "react-quill-new/dist/quill.snow.css";
import { RootState } from "../Redux/store";
import {
  copyToClipboard,
  generateSystemPrompt,
  sortByAscending,
} from "../utils/utils";
import { systemPrompt, Languages } from "../utils/label";
import Output from "./feature/Output";
import Settings from "./feature/Settings";
import axios from "axios";
import Header from "./common/Header";
import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";
import API_BASE_URL from "../config";
import { useDispatch } from "react-redux";
import { useModel } from "../ModelContext";



interface Prompt {
  id: number;
  name: string;
  text: string;
  userId?: number; // userId might not always be returned from the API
  createdAt?: string;
  template?: string;
}

const modules = {
  toolbar: [
    [
      { header: "1" },
      { header: "2" },
      { header: "3" },
      { header: "4" },
      { header: "5" },
      { header: "6" },
      [{ size: ["14px", "16px", "18px"] }],
      { font: [] },
    ],
    ["bold", "italic", "underline", "strike"],
    [{ color: [] }, { background: [] }],
    [{ align: [] }],
    [{ list: "ordered" }, { list: "bullet" }],
    // ["blockquote", "code-block"],
    [{ script: "sub" }, { script: "super" }],
    // ["link", "image", "video"],
    ["clean"],
  ],
};

interface SearchTermForm {
  searchCount: string;
  searchTerm: string;
  instructions: string;
  output: string;
  [key: string]: string; // For any additional properties
}

interface Client {
  firstName: string;
  lastName: string;
  clientID: number;
  companyName: string;
}

interface PitchGenDataResponse {
  data: EmailEntry[];
  nextPageToken?: string;
  more_records?: boolean;
}

interface OutputInterface {
  outputForm: {
    generatedContent: string;
    linkLabel: string;
    usage: string;
    currentPrompt: string;
    searchResults: string[];
    allScrapedData: string;
    onClearContent?: (clearContent: () => void) => void; // Add this line
  };

  outputFormHandler: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  setOutputForm: React.Dispatch<
    React.SetStateAction<{
      generatedContent: string;
      linkLabel: string;
      usage: string;
      currentPrompt: string;
      searchResults: string[];
      allScrapedData: string;
    }>
  >;
  allResponses: any[];
  isPaused: boolean;
  setAllResponses: React.Dispatch<React.SetStateAction<any[]>>;
  currentIndex: number;
  setCurrentIndex: React.Dispatch<React.SetStateAction<number>>;
  onClearOutput: () => void; // Add this line
  allprompt: any[];
  setallprompt: React.Dispatch<React.SetStateAction<any[]>>;
  allsearchResults: any[];
  setallsearchResults: React.Dispatch<React.SetStateAction<any[]>>;
  everyscrapedData: any[];
  seteveryscrapedData: React.Dispatch<React.SetStateAction<any[]>>;
  allSearchTermBodies: string[];
  setallSearchTermBodies: React.Dispatch<React.SetStateAction<string[]>>;
  allsummery: any[];
  setallsummery: React.Dispatch<React.SetStateAction<any[]>>;
  existingResponse: any[];
  setexistingResponse: React.Dispatch<React.SetStateAction<any[]>>;
  handleNextPage: () => Promise<void>;
  handlePrevPage: () => Promise<void>;
}
interface EmailEntry {
  id?: string;
  full_Name?: string;
  job_Title?: string;
  account_name_friendlySingle_Line_12?: string;
  mailing_Country?: string;
  website?: string;
  linkedIn_URL?: string;
  sample_email_body?: string;
  generated: boolean;
}

interface SettingsFormType {
  overwriteDatabase: boolean;
  // Add any other properties that your settingsForm has
}

const MainPage: React.FC = () => {

  const [formData, setFormData] = useState({
    Server:'',
    Port:'',
    Username:'',
    Password:'',
    useSsl:''
  });




  const [showPopup, setShowPopup] = useState(false);
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null);
  const [userRole, setUserRole] = useState<string>(""); // Store user role
  const userId = useSelector((state: RootState) => state.auth.userId);
  const [selectedDataFile, setSelectedDataFile] = useState(null);
  const [allsearchResults, setallsearchResults] = useState<any[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [allResponses, setAllResponses] = useState<any[]>([]);
  const [everyscrapedData, seteveryscrapedData] = useState<any[]>([]);
  const [allprompt, setallprompt] = useState<any[]>([]);
  const [allSearchTermBodies, setallSearchTermBodies] = useState<string[]>([]);
  const [clearContentFunction, setClearContentFunction] = useState<
    (() => void) | null
  >(null);
  const [allsummery, setallsummery] = useState<any[]>([]);
  const [loading, setLoading] = useState(true); // Initial loading state for fetching Zoho clients
  const [emailLoading, setEmailLoading] = useState(false); // Loading state for fetching email data

  const [currentPageToken, setCurrentPageToken] = useState<string | null>(null);
  const [nextPageToken, setNextPageToken] = useState<string | null>(null);
  const [prevPageToken, setPrevPageToken] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [existingResponse, setexistingResponse] = useState<any[]>([]);
  const [clearExistingResponse, setClearExistingResponse] = useState<
    () => void
  >(() => {});
  const [selectedClient, setSelectedClient] = useState<string>("");
  const [clientNames, setClientNames] = useState<Client[]>([]);
  const [clientSettings, setClientSettings] = useState<any>({});

  const [lastProcessedToken, setLastProcessedToken] = useState(null);
  const [lastProcessedIndex, setLastProcessedIndex] = useState(0);
  const stopRef = useRef(false);
  const [isStarted, setIsStarted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPitchUpdateCompleted, setIsPitchUpdateCompleted] = useState(false);
  const [pitchGenData, setPitchGenData] = useState<PitchGenDataResponse>({
    data: [],
  }); // Store the entire response

  const apiUrl = `${API_BASE_URL}/api/auth/getprompts/${userId}`;
  const [promptList, setPromptList]: any = useState([]);
  const [pitchResponses, setPitchResponses] = useState([]);
  const [, forceUpdate] = useState(false); // Force re-render

  const dispatch = useDispatch();
  const { selectedModelName } = useModel(); // Selected model name
  const [selectedZohoviewId, setSelectedZohoviewId] = useState<string>("");
  const {
    username,
    firstName,
    lastName,
    ipAddress,
    browserName,
    browserVersion
  } = useSelector((state: RootState) => state.auth);
  

  console.log(userRole, "userRole");
  console.log(selectedModelName, "selectedModelName");

 

  const handleClearContent = useCallback((clearContent: () => void) => {
    setClearContentFunction(() => clearContent);
  }, []);

  // Async stop function to allow context switching
  const stop = () => {
    stopRef.current = !stopRef.current;
    forceUpdate((prev) => !prev);
    setIsPaused(!isPaused);
    // Don't reset lastProcessedToken and lastProcessedIndex here
    // They will be used when resuming
  };

  const reset = () => {
    stopRef.current = false;
    setIsPaused(false);
    setLastProcessedToken(null);
    setLastProcessedIndex(0);
  };

  //Dropdown Of Client
  useEffect(() => {
    const fetchClientData = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/auth/allUserDetails`);
        const data: Client[] = await response.json();
        setClientNames(data);
      } catch (error) {
        console.error("Error fetching client details:", error);
      }
    };

    if (userRole === "ADMIN") {
      fetchClientData();
    }
  }, [userRole, API_BASE_URL]);

  // Function to handle user's response
  const handlePopupResponse = (shouldStop: boolean) => {
    setShowPopup(false);
    if (!shouldStop) {
      stopRef.current = false; // Reset stop request if user cancels
    }
  };

  const handleNewDataFileSelection = () => {
    // Call the clear function when a new data file is selected
    if (clearExistingResponse) {
      clearExistingResponse();
    }

    // Additional logic for handling new data file selection can be added here
  };

  // Handle change event for the select element
  const handleZohoModelChange = async (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const selectedId = event.target.value;
    setSelectedZohoviewId(selectedId); // Update the global state

    // Call the clear function when a new data file is selected
    handleNewDataFileSelection();

    if (selectedId) {
      try {
        await fetchAndDisplayEmailBodies(selectedId); // Fetch data
      } catch (error) {
        console.error("Error fetching email bodies:", error);
      }
    }
  };

  const handleSelectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedLabel = event.target.value;

    const prompt = promptList.find((p: Prompt) => p.name === selectedLabel);
    console.log(prompt, "pitch");
    setSelectedPrompt(prompt || null);
  };

  const handleDescriptionChange = (
    e: React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    setSelectedPrompt((prev) => ({
      ...prev!,
      body: e.target.value,
    }));
    console.log(setSelectedPrompt, "selectedPitch");
  };

  const [selectedLanguage, setSelectedLanguage] = useState<Languages>(
    Object.values(Languages).includes("English" as Languages)
      ? ("English" as Languages)
      : Object.values(Languages)[0]
  );

  const clientID = sessionStorage.getItem("clientId");
  const [zohoClient, setZohoClient] = useState<ZohoClient[]>([]);

  const handleLanguageChange = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setSelectedLanguage(event.target.value as Languages);
  };

  const [openModals, setOpenModals] = useState<{ [key: string]: boolean }>({});

  const handleModalOpen = (id: string) => {
    setOpenModals((prev) => ({ ...prev, [id]: true }));
  };

  const handleModalClose = (id: string) => {
    setOpenModals((prev) => ({ ...prev, [id]: false }));
  };

  const fetchPromptsList = useCallback(async () => {
    setEmailLoading(true); // Start loading indicator

    try {
      let url = apiUrl; // Default to current user's prompts

      // If a client is selected, modify the URL to fetch prompts for that client
      if (selectedClient !== "") {
        url = `${API_BASE_URL}/api/auth/getprompts/${selectedClient}`;
      }

      const response = await fetch(url);
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(
          `HTTP error! status: ${response.status}, message: ${errorText}`
        );
      }
      const data: Prompt[] = await response.json();
      console.log("Fetched prompts:", data);
      setPromptList(data);
    } catch (err) {
      console.error("Error fetching prompts:", err);
      setPromptList([]); // Ensure the list is empty in case of an error
    } finally {
      setEmailLoading(false); // Set loading to false when fetching is done
    }
  }, [selectedClient, apiUrl, API_BASE_URL]);

  useEffect(() => {
    // Clear the prompt list immediately when a new client is selected
    setPromptList([]);
    fetchPromptsList();
  }, [selectedClient, fetchPromptsList]);

  const handleClientChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedClient(event.target.value);
  };

  useEffect(() => {
    const isAdminString = sessionStorage.getItem("isAdmin");
    const isAdmin = isAdminString === "true"; // Correct comparison
    setUserRole(isAdmin ? "ADMIN" : "USER");
  }, []);

  // Add a prompt
  const [addPrompt, setAddPrompt] = useState({
    promptName: "",
    promptInput: "",
    promptTemplate: "",
  });
  const [editPrompt, setEditPrompt] = useState({
    promptName: "",
    promptInput: "",
    promptTemplate: "",
  }) as any;

  const addPromptHandler = (
    e:
      | React.ChangeEvent<HTMLInputElement>
      | React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;

    setAddPrompt({
      ...addPrompt,
      [name]: value,
    });
  };
  const editPromptHandler = (
    e:
      | React.ChangeEvent<HTMLInputElement>
      | React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;

    setEditPrompt({
      ...editPrompt,
      [name]: value,
    });
  };
  const addPromptSubmitHandler = (e: any) => {
    e.preventDefault();
    createPromptList();
  };
  const setEditHandler = () => {
    setEditPrompt({
      promptName: selectedPrompt?.name,
      promptInput: selectedPrompt?.text,
      promptTemplate: selectedPrompt?.template,
    });
  };
  const editPromptSubmitHandler = (e: any) => {
    e.preventDefault();
    editPromptList();
  };

  const [editPromptAlert, setEditPromptAlert] = useState(false);

  const editPromptList = useCallback(async () => {
    if (
      !editPrompt?.promptName ||
      !editPrompt?.promptInput ||
      !editPrompt?.promptTemplate
    )
      return;

    // Determine which ID to use for the update
    const effectiveUserId = selectedClient !== "" ? selectedClient : userId;

    if (!effectiveUserId || Number(effectiveUserId) <= 0) {
      console.error("Invalid userId or clientID:", effectiveUserId);
      return;
    }

    const id = selectedPrompt?.id; // Get the ID from selectedPrompt

    if (!id || Number(id) <= 0) {
      console.error("Invalid prompt ID:", id);
      return;
    }

    const dataToSend = {
      id: id, // Include the ID for the update
      name: editPrompt?.promptName,
      text: editPrompt?.promptInput,
      userId: effectiveUserId, // Use the determined ID
      createdAt: "2025-02-12T15:15:53.666Z", // This should be updated or removed based on your backend requirements
      template: editPrompt?.promptTemplate,
    };

    try {
      const res = await axios.post(
        `${API_BASE_URL}/api/auth/updateprompt`,
        dataToSend,
        { headers: { "Content-Type": "application/json" } }
      );

      console.log("Prompt updated successfully:", res);
      setEditPrompt({ promptName: "", promptInput: "", promptTemplate: "" }); // Reset the form
      setEditPromptAlert((prev) => !prev);
      setTimeout(() => {
        setEditPromptAlert((prev) => !prev);
      }, 3000);
      await fetchPromptsList(); // Refresh the prompt list
    } catch (error: any) {
      console.error(
        "Error updating prompt:",
        error.response?.data || error.message
      );
      // Handle error, display message to user, etc.
    }
  }, [
    editPrompt?.promptInput,
    editPrompt?.promptName,
    editPrompt?.promptTemplate,
    selectedPrompt?.id,
    userId,
    selectedClient,
    fetchPromptsList,
    setEditPrompt,
    setEditPromptAlert,
  ]);

  const [addPromptAlert, setAddPromptAlert] = useState(false);

  const createPromptList = useCallback(async () => {
    if (!addPrompt?.promptName || !addPrompt?.promptInput) return;

    // Determine which ID to use for the creation
    const effectiveUserId =
      selectedClient !== "" ? Number(selectedClient) : Number(userId);

    if (!effectiveUserId || effectiveUserId <= 0) {
      console.error("Invalid userId or clientID:", effectiveUserId);
      return;
    }

    const dataToSend = {
      name: addPrompt.promptName,
      text: addPrompt.promptInput,
      userId: effectiveUserId, // Use the determined ID
      createdAt: new Date().toISOString(),
      template: addPrompt.promptTemplate,
    };

    try {
      const res = await axios.post(
        `${API_BASE_URL}/api/auth/addprompt`,
        dataToSend,
        { headers: { "Content-Type": "application/json" } }
      );

      console.log("Prompt created successfully:", res);
      setAddPrompt({ promptName: "", promptInput: "", promptTemplate: "" });
      setAddPromptAlert((prev) => !prev);
      setTimeout(() => {
        setAddPromptAlert((prev) => !prev);
      }, 3000);
      await fetchPromptsList();
    } catch (error) {
      console.error("Error creating prompt:", error);
    }
  }, [
    addPrompt,
    userId,
    selectedClient,
    fetchPromptsList,
    setAddPrompt,
    setAddPromptAlert,
  ]);

  const deletePromptHandler = async () => {
    if (!selectedPrompt) {
      console.error("No prompt selected to delete.");
      return;
    }

    // Determine which ID to use for the deletion
    const effectiveUserId = selectedClient !== "" ? selectedClient : userId;

    if (!effectiveUserId || Number(effectiveUserId) <= 0) {
      console.error("Invalid userId or clientID:", effectiveUserId);
      return;
    }

    try {
      const response = await fetch(
        `${API_BASE_URL}/api/auth/deleteprompt/${selectedPrompt.id}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ userId: Number(effectiveUserId) }),
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(
          `HTTP error! status: ${response.status}, message: ${errorText}`
        );
      }

      // Get the updated prompt list from the API
      let updatedPromptsResponse;
      if (selectedClient !== "") {
        updatedPromptsResponse = await fetch(
          `${API_BASE_URL}/api/auth/getprompts/${selectedClient}`
        );
      } else {
        updatedPromptsResponse = await fetch(apiUrl);
      }

      if (!updatedPromptsResponse.ok) {
        const errorText = await updatedPromptsResponse.text();
        throw new Error(
          `HTTP error fetching prompts: ${updatedPromptsResponse.status}, message: ${errorText}`
        );
      }

      const updatedPromptList = await updatedPromptsResponse.json();
      setPromptList(updatedPromptList); // Update the promptList state
      handleModalClose("modal-confirm-delete");

      console.log("Prompt deleted and prompt list updated:", updatedPromptList);
      setSelectedPrompt(null); // Clear the selected prompt
    } catch (error) {
      console.error("Error deleting prompt or fetching updated list:", error);
      // Handle error, e.g., show message to user
    }
  };

  const [tab, setTab] = useState("Template");

  const tabHandler = (e: React.MouseEvent<HTMLButtonElement>) => {
    const { innerText } = e.currentTarget;
    setTab(innerText);
  };

  const [tab2, setTab2] = useState("Template");
  const tabHandler2 = (e: React.ChangeEvent<any>) => {
    const { innerText } = e.target;
    console.log(innerText, "innerText");
    setTab2(innerText);
  };

  const [tab3, setTab3] = useState("Template");
  const tabHandler3 = (e: React.ChangeEvent<any>) => {
    const { innerText } = e.target;
    console.log(innerText, "innerText");
    setTab3(innerText);
  };

  const [tab4, setTab4] = useState("Template");
  const tabHandler4 = (e: React.ChangeEvent<any>) => {
    const { innerText } = e.target;
    console.log(innerText, "innerText");
    setTab4(innerText);
  };

  const [delayTime, setDelay] = useState<number>(0);
  const delay = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));

  const [startTime, setStartTime] = useState<Date | null>(null);
  const [endTime, setEndTime] = useState<Date | null>(null);
  const [timeSpent, setTimeSpent] = useState<string>("");

  const [currentEmailIndex, setCurrentEmailIndex] = useState<number>(0);
  const [emailData, setEmailData] = useState<any[]>([]);

  const fetchAndDisplayEmailBodies = useCallback(
    async (
      zohoviewId: string,
      pageToken: string | null = null,
      direction: "next" | "previous" | null = null
    ) => {
      try {
        setEmailLoading(true);
        let url = `${API_BASE_URL}/api/auth/pitchgenData/${zohoviewId}`;
        if (pageToken) {
          url += `?pageToken=${encodeURIComponent(pageToken)}`;
        }

        const response = await fetch(url);
        if (!response.ok) {
          throw new Error("Failed to fetch email bodies");
        }

        const fetchedEmailData = await response.json();
        if (!Array.isArray(fetchedEmailData.data)) {
          console.error("Invalid data format");
          return;
        }

        // Map fetched data to the desired format, including pagination tokens
        const emailResponses = fetchedEmailData.data.map(
          (entry: EmailEntry) => ({
            id: entry.id,
            name: entry.full_Name || "N/A",
            title: entry.job_Title || "N/A",
            company: entry.account_name_friendlySingle_Line_12 || "N/A",
            location: entry.mailing_Country || "N/A",
            website: entry.website || "N/A",
            linkedin: entry.linkedIn_URL || "N/A",
            pitch: entry.sample_email_body || "No email body found",
            timestamp: new Date().toISOString(),
            nextPageToken: fetchedEmailData.nextPageToken,
            prevPageToken: fetchedEmailData.previousPageToken,
            generated: false,
          })
        );

        // Update existingResponse based on the direction of pagination
        if (direction === "next") {
          setexistingResponse((prevResponses) => [
            ...prevResponses,
            ...emailResponses,
          ]);
        } else if (direction === "previous") {
          setexistingResponse((prevResponses) => [
            ...emailResponses,
            ...prevResponses,
          ]);
        } else {
          // Initial load or no direction specified, replace existing data
          setexistingResponse(emailResponses);
        }

        // Update pagination tokens in state (if needed elsewhere)
        setNextPageToken(fetchedEmailData.nextPageToken || null);
        setPrevPageToken(fetchedEmailData.previousPageToken || null);
      } catch (error) {
        console.error("Error fetching email bodies:", error);
      } finally {
        setEmailLoading(false);
      }
    },
    []
  );

  const handleNextPage = async () => {
    if (currentPage < existingResponse.length - 1) {
      setCurrentPage((prevPage) => prevPage + 1);
    } else {
      const lastItem = existingResponse[existingResponse.length - 1];
      if (lastItem?.nextPageToken) {
        await fetchAndDisplayEmailBodies(
          selectedZohoviewId,
          lastItem.nextPageToken,
          "next"
        );
        setCurrentPage(0); // Reset to the beginning of the new page
      }
    }
  };

  const handlePrevPage = async () => {
    if (currentPage > 0) {
      setCurrentPage((prevPage) => prevPage - 1);
    } else {
      const firstItem = existingResponse[0];
      if (firstItem?.prevPageToken) {
        await fetchAndDisplayEmailBodies(
          selectedZohoviewId,
          firstItem.prevPageToken,
          "previous"
        );
        // Update currentPage to point to the last item of the prepended data
        setCurrentPage(
          existingResponse.length > 0 ? existingResponse.length - 1 : 0
        );
      }
    }
  };

  const sendEmail = async (
    cost: number,
    failedReq: number,
    successReq: number,
    scrapfailedReq: number,
    totaltokensused: number,
    timeSpent: string,
    startTime: Date | null,
    endTime: Date | null,
    generatedPitches: any[] = [],
    promptText: string = "No prompt template was selected"
  ) => {
    // use the values from the top of your component!
    const formattedStartTime = startTime ? startTime.toLocaleString() : "N/A";
    const formattedEndTime = endTime ? endTime.toLocaleString() : "N/A";
    const lastPitch =
      generatedPitches.length > 0
        ? generatedPitches[generatedPitches.length - 1].pitch
        : "No pitches were generated in this session";
    const ipLink =
      ipAddress && ipAddress !== "Unavailable"
        ? `<a href="https://whatismyipaddress.com/ip/${ipAddress}" target="_blank">${ipAddress}</a>`
        : ipAddress || "Unavailable";
  
    const emailData = {
      To: "info@groupji.co, rushikeshg@groupji.co",
      Subject: "Processing Report",
      Body: `
        <html>
        <head>
            <style>
                body, html { margin: 0 !important; padding: 0 !important; line-height: 1.4 !important; font-family: Arial, sans-serif; }
                div { margin: 0 0 10px 0 !important; }
                .section { margin-bottom: 20px !important; padding-bottom: 10px !important; border-bottom: 1px solid #eee; }
                .pitch { background-color: #f9f9f9; padding: 15px; border-left: 4px solid #4CAF50; margin: 10px 0; }
            </style>
        </head>
        <body>
            <div class="section">
                <h2>User Info:</h2>
                <p><strong>Username:</strong> ${username || "N/A"}</p>
                <p><strong>User ID:</strong> ${userId || "N/A"}</p>
                <p><strong>User Role:</strong> ${userRole || "N/A"}</p>
                <p><strong>First Name:</strong> ${firstName || "N/A"}</p>
                <p><strong>Last Name:</strong> ${lastName || "N/A"}</p>
            </div>
            <div class="section">
                <h2>Device Info:</h2>
                <p><strong>IP Address:</strong> ${ipLink}</p>
                <p><strong>Browser:</strong> ${browserName || "N/A"}</p>
                <p><strong>Browser Version:</strong> ${browserVersion || "N/A"}</p>
            </div>
            <div class="section">
                <h2>Timings:</h2>
                <p><strong>Start time of the process:</strong> ${formattedStartTime}</p>
                <p><strong>End time of the process:</strong> ${formattedEndTime}</p>
                <p><strong>Time spent:</strong> ${timeSpent}</p>
            </div>
            <div class="section">
                <h2>Costs:</h2>
                <p><strong>Total records successfully processed:</strong> ${successReq}</p>
                <p><strong>Total records failed to process:</strong> ${failedReq}</p>
                <p><strong>Total scrap data failed requests:</strong> ${scrapfailedReq}</p>
                <p><strong>Total tokens used:</strong> ${totaltokensused}</p>
                <p><strong>Total cost of the transaction:</strong> $${cost.toFixed(2)}</p>
            </div>
            <div class="section">
                <h2>Prompt Template Used:</h2>
                <div class="prompt">${promptText}</div>
            </div>
            <div class="section">
                <h2>Last Generated Pitch:</h2>
                <div class="pitch">${lastPitch}</div>
            </div>
        </body>
        </html>
      `,
    };

    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/sendemail`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(emailData),
      });
  
      if (!response.ok)
        throw new Error(`Failed to send email: ${response.statusText}`);
  
      const result = await response.json();
      console.log("Email sent successfully:", result);
    } catch (error) {
      console.error("Error sending email:", error);
    }
  };

  var cost = 0;
  var failedReq = 0;
  var successReq = 0;
  var scrapfailedreq = 0;
  var totaltokensused = 0;

  // Helper function to format date and time

  // Helper function to format date and time
  function formatDateTime(date: Date): string {
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
  }

  const fetchClientSettings = async (clientID: number): Promise<any> => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/auth/clientSettings/${clientID}`
      );
      if (!response.ok) {
        throw new Error("Failed to fetch client settings");
      }
      const settings = await response.json();

      if (!settings || settings.length === 0) {
        console.warn("No settings found for the given Client ID");
        return {}; // Return an empty object if no settings are found
      }

      // Assuming the first object in the array is the relevant settings
      const clientSettings = settings[0];

      return {
        modelName: clientSettings.model_name,
        searchCount: clientSettings.search_URL_count,
        searchTerm: clientSettings.search_term,
        instructions: clientSettings.instruction,
        systemInstructions: clientSettings.system_instruction,
      };
    } catch (error) {
      console.error("Error fetching client settings:", error);
      return {}; // Return an empty object in case of an error
    }
  };

  const goToTab = async (tab: string) => {
    setTab(tab);

    // If already processing, show loader and prevent multiple starts
    if (isProcessing) {
      return;
    }
    // Fetch default values from API
    const defaultValues = await fetchClientSettings(Number(clientID));
    // Determine which values to use
    const selectedModelNameA = selectedModelName || defaultValues.modelName;
    const searchterm = searchTermForm.searchTerm || defaultValues.searchTerm;
    const searchCount = searchTermForm.searchCount || defaultValues.searchCount;
    const instructionsParamA =
      searchTermForm.instructions || defaultValues.instructions;
    const systemInstructionsA =
      settingsForm.systemInstructions || defaultValues.systemInstructions;

    const startTime = new Date();
    setStartTime(startTime);
    let generatedPitches: any[] = []; // Declare and initialize generatedPitches

    try {
      debugger;
      setIsProcessing(true);
      let nextPageToken = lastProcessedToken || null;
      let moreRecords = true;
      let currentIndex = isPaused ? lastProcessedIndex : 0;
      let foundRecordWithoutPitch = false; // Flag to track if we found a record without a pitch

      // Show loader
      setOutputForm((prevForm) => ({
        ...prevForm,
        generatedContent:
          '<span style="color: blue">Processing initiated...please wait...</span><br/>' +
          prevForm.generatedContent,
      }));

      while (moreRecords) {
        const response: Response = await fetch(
          `${API_BASE_URL}/api/auth/pitchgenData/${selectedZohoviewId}?pageToken=${
            nextPageToken || ""
          }`
        );

        if (!response.ok) {
          throw new Error("Failed to fetch email bodies");
        }

        const data = await response.json();
        if (!Array.isArray(data.data)) {
          console.error("Invalid data format");
          break;
        }

        // Start from the stored index if resuming, otherwise start from 0
        const startIndex =
          isPaused && nextPageToken === lastProcessedToken
            ? lastProcessedIndex
            : 0;
        for (let i = startIndex; i < data.data.length; i++) {
          const entry = data.data[i];

          if (stopRef.current === true) {
            // Store the current position before stopping
            setLastProcessedToken(nextPageToken);
            setLastProcessedIndex(i);
            return; // Exit the function entirely when paused

            moreRecords = false;
            break;
          }

          // Process the entry as before
          // ... (keep the existing code for processing each entry)

          const urlParam: string = `https://www.${entry.email.split("@")[1]}`;
          try {
            var company_name_friendly =
              entry.account_name_friendlySingle_Line_12;
            var full_name = entry.full_Name;
            var job_title = entry.job_Title;
            var location = entry.mailing_Country;
            var linkedin_url = entry.linkedIn_URL;
            var emailbody = entry.sample_email_body;
            var website = entry.website;
            var company_name = entry.account_Name.name;

            // Check if email already exists and if we should overwrite
            if (entry.sample_email_body && !settingsForm.overwriteDatabase) {
              setOutputForm((prevOutputForm) => ({
                ...prevOutputForm,
                generatedContent:
                  `<span style="color: orange">[${formatDateTime(
                    new Date()
                  )}] Pitch for contact ${full_name} with company name ${company_name} and domain ${
                    entry.email
                  } </span><br/>` + prevOutputForm.generatedContent,
                linkLabel: entry.sample_email_body, // Show the existing pitch in the linkable area
              }));

              await delay(delayTime * 1000);

              const existingResponse = {
                ...entry,
                name: entry.full_Name || "N/A",
                title: entry.job_Title || "N/A",
                company: entry.account_name_friendlySingle_Line_12 || "N/A",
                location: entry.mailing_Country || "N/A",
                website: entry.website || "N/A",
                linkedin: entry.linkedIn_URL || "N/A",
                pitch: entry.sample_email_body,
                timestamp: new Date().toISOString(),
                generated: false, // Indicate this is an existing pitch, not newly generated
              };

              // Add to responses and update the current index
              setAllResponses((prevResponses) => {
                const newResponses = [...prevResponses, existingResponse];
                // Set the current index to the last item
                setCurrentIndex(newResponses.length - 1);
                return newResponses;
              });
              generatedPitches.push(existingResponse);

              continue; // Skip to the next entry
            } else {
              // Record without a pitch found
              foundRecordWithoutPitch = true;

              // If in demo mode and we found a record without a pitch, stop processing
              if (isDemoAccount) {
                setOutputForm((prevOutputForm) => ({
                  ...prevOutputForm,
                  generatedContent:
                    `<span style="color: blue">[${formatDateTime(
                      new Date()
                    )}] Subscription: Trial mode. Processing is paused. Contact support on Live Chat (bottom right) or London: +44 (0) 207 660 4243 | New York: +1 (0) 315 400 2402 or email info@dataji.co </span><br/>` + 
                    prevOutputForm.generatedContent,
                }));

                // Set flags to stop processing
                moreRecords = false;
                stopRef.current = true;
                setLastProcessedToken(nextPageToken);
                setLastProcessedIndex(i);
                break; // Exit the loop
              }
            }

            // **Step 1: Scrape Website**
            var company_name = entry.account_name_friendlySingle_Line_12;
            const searchTermBody = searchterm.replace(
              "{company_name}",
              company_name
            );
            const instructions = instructionsParamA
              .replace("{company_name}", company_name)
              .replace("{job_title}", job_title)
              .replace("{location}", location)
              .replace("{full_name}", full_name)
              .replace("{linkedin_url}", linkedin_url)
              .replace("{linkedin_url}", company_name_friendly);

            const instructionsParam = encodeURIComponent(instructionsParamA);

            setallSearchTermBodies((prevSearchTermBodies) => [
              ...prevSearchTermBodies,
              searchTermBody.replace("{company_name}", company_name),
            ]);

            setOutputForm((prevOutputForm) => {
              const formattedTime = formatDateTime(new Date());

              return {
                ...prevOutputForm,
                generatedContent:
                  `<span style="color: orange">[${formattedTime}] Generating phase #1 societatis, for contact ${full_name} with company name ${company_name} and domain ${entry.email}</span><br/>` +
                  prevOutputForm.generatedContent,
              };
            });

            const modelNameParam = encodeURIComponent(selectedModelNameA);
            const searchCountParam = encodeURIComponent(
              searchTermForm.searchCount
            );

            const scrapeResponse = await fetch(
              `${API_BASE_URL}/api/auth/process?instructions=${instructionsParam}&modelName=${encodeURIComponent(
                selectedModelNameA
              )}&searchCount=${encodeURIComponent(searchCount)}`,
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(searchTermBody), // Send only searchTerm in the body
              }
            );

            if (!scrapeResponse.ok) {
              const formattedTime = formatDateTime(new Date());

              scrapfailedreq += 1;
              setOutputForm((prevOutputForm) => ({
                ...prevOutputForm,
                generatedContent:
                  `<span style="color: red">[${formatDateTime(
                    new Date()
                  )}] Search incomplete for contact ${full_name} with company name ${company_name} and domain ${
                    entry.email
                  }</span><br/>` + prevOutputForm.generatedContent,
                usage:
                  `Cost: $${cost.toFixed(6)}    ` +
                  `Failed Requests: ${failedReq}    ` +
                  `Success Requests: ${successReq}               ` +
                  `Scraped Data Failed Requests: ${scrapfailedreq}   ` +
                  `Total Tokens Used: ${totaltokensused}   `,
              }));
              generatedPitches.push({
                ...entry,
                pitch: "Error scraping website",
              });
              continue; // Move to the next entry
            }
            const scrapeData = await scrapeResponse.json();
            // Update allsummery state

            const summary = scrapeData.pitchResponse || {};
            const searchResults = scrapeData.searchResults || [];
            const scrappedData = summary.content || "";

            if (!scrappedData) {
              const formattedTime = formatDateTime(new Date());
              scrapfailedreq += 1;
              setOutputForm((prevOutputForm) => ({
                ...prevOutputForm,
                searchResults: scrapeData.searchResults || [],
                allScrapedData: scrapeData.allScrapedData || "",
                generatedContent:
                  `<span style="color: red">[${formatDateTime(
                    new Date()
                  )}] Centum nulla analysis incomplete for contact ${full_name} with company name ${company_name} and domain ${
                    entry.email
                  }</span><br/>` + prevOutputForm.generatedContent,
                usage:
                  `Cost: $${cost.toFixed(6)}    ` +
                  `Failed Requests: ${failedReq}    ` +
                  `Success Requests: ${successReq}              ` + //
                  `Scraped Data Failed Requests: ${scrapfailedreq}   ` +
                  `Total Tokens Used: ${totaltokensused}   `,
              }));
              generatedPitches.push({
                ...entry,
                pitch: "Error scraping website",
              });
              continue;
            }

            let systemPrompt = systemInstructionsA;

            const replacedPromptText = (selectedPrompt?.text || "")
              .replace("{search_output_summary}", scrappedData)
              .replace("{company_name}", company_name)
              .replace("{job_title}", job_title)
              .replace("{location}", location)
              .replace("{full_name}", full_name)
              .replace("{linkedin_url}", company_name_friendly)
              .replace("{linkedin_url}", linkedin_url);

            const promptToSend = `
          
          ${systemPrompt}
           
          ${replacedPromptText}`
              .replace("{search_output_summary}", scrappedData)
              .replace("{company_name}", company_name)
              .replace("{job_title}", job_title)
              .replace("{location}", location)
              .replace("{full_name}", full_name)
              .replace("{linkedin_url}", company_name_friendly)
              .replace("{linkedin_url}", linkedin_url);

            setOutputForm((prevState) => ({
              ...prevState,
              currentPrompt: promptToSend,
              searchResults: scrapeData.searchResults || [],
              allScrapedData: scrapeData.allScrapedData || "",
            }));

            setOutputForm((prevOutputForm) => ({
              ...prevOutputForm,
              searchResults: scrapeData.searchResults || [],
              allScrapedData: scrapeData.allScrapedData || "",
              generatedContent:
                `<span style="color: blue">[${formatDateTime(
                  new Date()
                )}] Generating phase #2 integritas, for contact ${full_name} with company name ${company_name} and domain ${
                  entry.email
                }</span><br/>` + prevOutputForm.generatedContent,
            }));
            debugger;

            const requestBody = {
              scrappedData: systemPrompt,
              prompt: `${selectedPrompt?.text}`
                .replace("{company_name}", company_name)
                .replace("{job_title}", job_title)
                .replace("{location}", location)
                .replace("{full_name}", full_name)
                .replace("{linkedin_url}", linkedin_url)
                .replace("{linkedin_url}", company_name_friendly)
                .replace("{search_output_summary}", scrappedData),

              ModelName: selectedModelNameA,
            };

            const pitchResponse = await fetch(
              `${API_BASE_URL}/api/auth/generatepitch`,
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(requestBody),
              }
            );

            const pitchData = await pitchResponse.json();
            if (!pitchResponse.ok) {
              const formattedTime = formatDateTime(new Date());
              failedReq += 1;
              cost += parseFloat(pitchData?.response?.currentCost);
              totaltokensused += parseFloat(pitchData?.response?.totalTokens);
              setOutputForm((prevOutputForm) => ({
                ...prevOutputForm,
                searchResults: scrapeData.searchResults || [],
                allScrapedData: scrapeData.allScrapedData || "",
                generatedContent:
                  `<span style="color: red">[${formatDateTime(
                    new Date()
                  )}] Phase #2 integritas incomplete for contact ${full_name} with company name ${company_name} and domain ${
                    entry.email
                  }</span><br/>` + prevOutputForm.generatedContent,
                usage:
                  `Cost: $${cost.toFixed(6)}    ` +
                  `Failed Requests: ${failedReq}    ` +
                  `Success Requests: ${successReq}                ` + //
                  `Scraped Data Failed Requests: ${scrapfailedreq}   ` +
                  `Total Tokens Used: ${totaltokensused}   `,
              }));
              generatedPitches.push({
                ...entry,
                pitch: "Error generating pitch",
              });
              continue;
            }

            successReq += 1;
            cost += parseFloat(pitchData?.response?.currentCost);
            totaltokensused += parseFloat(pitchData?.response?.totalTokens);
            console.log(`Cosstdata ${pitchData}`);
            // Success: Update UI with the generated pitch
            setOutputForm((prevOutputForm) => ({
              ...prevOutputForm,
              searchResults: scrapeData.searchResults || [],
              allScrapedData: scrapeData.allScrapedData || "",
              generatedContent:
                `<span style="color: green">[${formatDateTime(
                  new Date()
                )}] Pitch successfully generated for contact ${full_name} with company name ${company_name} and domain ${
                  entry.email
                }</span><br/>` + prevOutputForm.generatedContent,
              usage:
                `Cost: $${cost.toFixed(6)}    ` +
                `Failed Requests: ${failedReq}    ` +
                `Success Requests: ${successReq}                  ` + //
                `Scraped Data Failed Requests: ${scrapfailedreq}   ` +
                `Total Tokens Used: ${totaltokensused}   `,
            }));

            setOutputForm((prevOutputForm) => ({
              ...prevOutputForm,
              linkLabel: pitchData.response.content,
            }));

            generatedPitches.push({
              ...entry,
              name: entry.full_Name || "N/A",
              title: entry.job_Title || "N/A",
              company: entry.account_name_friendlySingle_Line_12 || "N/A",
              location: entry.mailing_Country || "N/A",
              website: entry.website || "N/A",
              linkedin: entry.linkedIn_URL || "N/A",
              pitch: pitchData.response.content,
            });

            const newResponse = {
              ...entry,
              name: entry.full_Name || "N/A",
              title: entry.job_Title || "N/A",
              company: entry.account_name_friendlySingle_Line_12 || "N/A",
              location: entry.mailing_Country || "N/A",
              website: entry.website || "N/A",
              linkedin: entry.linkedIn_URL || "N/A",
              pitch: pitchData.response.content,
              timestamp: new Date().toISOString(),
              id: entry.id, // Include the ID
              nextPageToken: data.nextPageToken, // Include next and previous page tokens
              prevPageToken: data.previousPageToken,
              generated: true,
            };

            setAllResponses((prevResponses) => [...prevResponses, newResponse]);
            generatedPitches.push(newResponse);
            setallprompt((prevPrompts) => [...prevPrompts, promptToSend]);
            setallsearchResults((prevSearchResults) => [
              ...prevSearchResults,
              scrapeData.searchResults || [],
            ]);
            seteveryscrapedData((prevScrapedData) => [
              ...prevScrapedData,
              scrapeData.allScrapedData || "",
            ]);
            setallsummery((prevSummery) => [
              ...prevSummery,
              scrapeData.pitchResponse.content || [],
            ]);

            // **Step 3: Update Zoho CRM**
            try {
              // Check if both contactId and emailBody are available before making the request
              if (entry.id && pitchData.response.content) {
                // Update contact
                const updateContactResponse = await fetch(
                  `${API_BASE_URL}/api/auth/updatezoho`,
                  {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      // Include any necessary authentication headers
                    },
                    body: JSON.stringify({
                      contactId: entry.id,
                      emailBody: pitchData.response.content,
                      accountId: "String",
                    }),
                  }
                );

                if (!updateContactResponse.ok) {
                  const updateContactError = await updateContactResponse.json();

                  setOutputForm((prevOutputForm) => ({
                    ...prevOutputForm,
                    generatedContent:
                      `<span style="color: orange">[${formatDateTime(
                        new Date()
                      )}] Updating contact in database incomplete for contact ${full_name} with company name ${company_name} and domain ${
                        entry.email
                      }. Error: ${updateContactError.Message}</span><br/>` +
                      prevOutputForm.generatedContent,
                  }));
                } else {
                  setOutputForm((prevOutputForm) => ({
                    ...prevOutputForm,
                    generatedContent:
                      `<span style="color: green">[${formatDateTime(
                        new Date()
                      )}] Updated pitch in database for contact ${full_name} with company name ${company_name} and domain ${
                        entry.email
                      }.</span><br/>` + prevOutputForm.generatedContent,
                  }));
                }
              } else {
                // Handle the error appropriately
                setOutputForm((prevOutputForm) => ({
                  ...prevOutputForm,
                  generatedContent:
                    `<span style="color: orange">[${formatDateTime(
                      new Date()
                    )}] Updating contact in database incomplete for contact ${full_name} with company name ${company_name} and domain ${
                      entry.email
                    }</span><br/>` + prevOutputForm.generatedContent,
                }));
              }
            } catch (zohoError) {
              setOutputForm((prevOutputForm) => ({
                ...prevOutputForm,
                generatedContent:
                  `<span style="color: orange">[${formatDateTime(
                    new Date()
                  )}] Updating contact in database incomplete for contact ${full_name} with company name ${company_name} and domain ${
                    entry.email
                  }. Error: </span><br/>` + prevOutputForm.generatedContent,
              }));
            }

            console.log("Delaying " + delayTime + " secs");
            // await delay(delayTime * 1000); // 1-second delay
          } catch (error) {
            setOutputForm((prevOutputForm: any) => ({
              ...prevOutputForm,
              generatedContent:
                `<span style="color: red">[${formatDateTime(
                  new Date()
                )}] Phase #2 integritas incomplete for contact ${
                  entry.firstName
                } with company name ${entry.companyName} and domain ${
                  entry.emailAddress
                }</span><br/>` + prevOutputForm.generatedContent,
              usage:
                `Cost: $${cost.toFixed(6)}    ` +
                `Failed Requests: ${failedReq}    ` +
                `Success Requests: ${successReq}                ` + //
                `Scraped Data Failed Requests: ${scrapfailedreq}   ` +
                `Total Tokens Used: ${totaltokensused}   `,
            }));
            console.error(
              `Error processing entry ${entry.emailAddress}:`,
              error
            );
            generatedPitches.push({
              ...entry,
              pitch: "Error generating pitch",
            });
          }
        }
        // Set processing to false when completely done

        nextPageToken = data.nextPageToken;
        moreRecords = data.moreRecords !== false;
        currentIndex = 0; // Reset index for new page
      }

      // Process completed successfully
      if (!stopRef.current) {
        // Reset all tracking variables
        setLastProcessedToken(null);
        setLastProcessedIndex(0);
        setIsPaused(false);
        stopRef.current = false;
      }

      // Capture the end time after processing all entries
      const endTime = new Date();
      setEndTime(endTime);

      // Calculate time spent
      const timeSpent = endTime.getTime() - startTime.getTime();
      const hours = Math.floor((timeSpent % 86400000) / 3600000);
      const minutes = Math.floor(((timeSpent % 86400000) % 3600000) / 60000);
      const formattedTimeSpent = `${hours} hours ${minutes} minutes`;

      // Send email report
      sendEmail(
        cost,
        failedReq,
        successReq,
        scrapfailedreq,
        totaltokensused,
        formattedTimeSpent,
        startTime,
        endTime,
        generatedPitches,
        selectedPrompt?.text
      );

    } catch (error) {
      // Ensure processing is set to false even if there's an error
      setIsProcessing(false);
      console.error("Error:", error);
      setOutputForm((prevForm) => ({
        ...prevForm,
        generatedContent:
          `<span style="color: red"> Error: </span><br/>` +
          prevForm.generatedContent,
      }));
    } finally {
      // Ensure processing is set to false
      setIsProcessing(false);
      setIsPitchUpdateCompleted(true); // Set to true when pitch is updated

    }
  };

  // const exportToExcel = (data: any[]) => {
  //   const ws = XLSX.utils.json_to_sheet(data);
  //   const wb = XLSX.utils.book_new();
  //   XLSX.utils.book_append_sheet(wb, ws, "Generated Pitches");

  //   // Create and download the Excel file
  //   XLSX.writeFile(wb, "Generated_Pitches.xlsx");
  // };



  const [outputForm, setOutputForm] = useState<OutputInterface["outputForm"]>({
    generatedContent: "",
    linkLabel: "",
    usage: "",
    currentPrompt: "",
    searchResults: [],
    allScrapedData: "",
  });

  const outputFormHandler = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      if (!e || !e.target) {
        console.error("Event is undefined or missing target:", e);
        return;
      }

      const { name, value } = e.target;
      setOutputForm((prevOutputForm) => ({
        ...prevOutputForm,
        [name]: value,
      }));
    },
    []
  );

  const clearOutputForm = () => {
    setOutputForm((prevForm) => ({
      ...prevForm,
      generatedContent: "",
    }));
  };

  const searchTermFormHandler = useCallback(
    (e: {
      target: {
        name: string;
        value: string;
      };
    }) => {
      const { name, value } = e.target;
      console.log("Handling form update:", { name, value });

      setSearchTermForm((prev: SearchTermForm) => ({
        ...prev,
        [name]: value,
      }));
    },
    []
  );

  // Also update the state declaration
  const [searchTermForm, setSearchTermForm] = useState<SearchTermForm>({
    searchCount: "",
    searchTerm: "",
    instructions: "",
    output: "",
  });

  const searchTermFormOnSubmit = async (e: any) => {
    e.preventDefault();
    try {
      console.log(searchTermForm.searchTerm, "searchTermForm");
      console.log(searchTermForm.instructions);
      console.log(searchTermForm.searchCount); // Log the number value

      const requestBody = searchTermForm.searchTerm; // Send only the search term in the body
      // const requestBody = {
      //   searchTerm: searchTermForm.searchTerm,
      //   searchCount: parseInt(searchTermForm.number) // Convert to integer
      // };
      const instructionsParam = encodeURIComponent(searchTermForm.instructions); // Encode to prevent URL issues
      const modelNameParam = encodeURIComponent(selectedModelName);
      const searchCountParam = encodeURIComponent(searchTermForm.searchCount);

      const response = await fetch(
        `${API_BASE_URL}/api/auth/process?instructions=${instructionsParam}&modelName=${modelNameParam}&searchCount=${searchCountParam}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(requestBody), // Send searchTerm in the body
        }
      );

      const data = await response.json();

      if (!response.ok) {
        console.error("API Error:", data);
        setSearchTermForm((prevForm: any) => ({
          ...prevForm,
          output: "Error processing request",
        }));
      } else {
        setSearchTermForm((prevForm: any) => ({
          ...prevForm,
          output: data.response.content, // Store the API response
        }));
      }
    } catch (error) {
      console.error("Error:", error);
      setSearchTermForm((prevForm: any) => ({
        ...prevForm,
        output: "Error processing request",
      }));
    }
  };
  const [settingsForm, setSettingsForm] = useState({
    emailTemplate: "",
    viewId: "",
    overwriteDatabase: false,
    tkInput: "",
    tkOutput: "",
    systemInstructions: systemPrompt,
  }) as any;

  const settingsFormHandler = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, type, checked, value } = e.target;
      const newValue = type === "checkbox" ? checked : value;
      // (e: any) => {
      //   const { name, value } = e.target;
      //   console.log(value, "settingsFormHandler");

      setSettingsForm((prevSettings: any) => ({
        ...prevSettings,
        [name]: newValue,
      }));
      // setSettingsForm({
      //   ...settingsForm,
      //   [name]: value,
      // });
    },
    [settingsForm]
  );

  const settingsFormOnSubmit = (e: any) => {
    e.preventDefault();
    console.log(outputForm, "outputForm");
    console.log(settingsForm, "settingForm");
  };

  // To handle RTE change
  const handleViewPromptRTE = useCallback(
    (value: string) => {
      if (selectedPrompt) {
        setSelectedPrompt((prev) => ({
          ...prev!,
          text: value,
        }));
      }
    },
    [selectedPrompt]
  );

  const handleEditPromptInputRTE = useCallback(
    (value: string) => {
      if (editPrompt) {
        setEditPrompt((prev: any) => ({
          ...prev!,
          promptInput: value,
        }));
      }
    },
    [editPrompt]
  );
  const handleEditPromptTemplateRTE = useCallback(
    (value: string) => {
      if (editPrompt) {
        setEditPrompt((prev: any) => ({
          ...prev!,
          promptTemplate: value,
        }));
      }
    },
    [editPrompt]
  );
  const handleAddPromptInPutRTE = useCallback(
    (value: string) => {
      if (addPrompt) {
        setAddPrompt((prev) => ({
          ...prev!,
          promptInput: value,
        }));
      }
    },
    [addPrompt]
  );
  const handleAddPromptTemplateRTE = useCallback(
    (value: string) => {
      if (addPrompt) {
        setAddPrompt((prev) => ({
          ...prev!,
          promptTemplate: value,
        }));
      }
    },
    [addPrompt]
  );

  // Convert line break to br
  const formatTextForDisplay = (text: string) => {
    return text.replace(/\n/g, "<br/>");
  };

  // Convert br tag to line break
  const formatTextForEditor = (text: string) => {
    return text.replace(/<br\/>/g, "\n");
  };

  interface ZohoClient {
    id: number;
    zohoviewId: string;
    zohoviewName: string;
    clientId: number;
    totalContact: number;
  }

  interface Contact {
    name: string;
    title: string;
    company: string;
    location: string;
    website: string;
    linkedin: string;
    pitch: string;
    timestamp: string;
  }
  const IsAdmin = sessionStorage.getItem("IsAdmin");

  useEffect(() => {
    const fetchZohoClient = async () => {
      setLoading(true); // Set loading to true before fetching
      try {
        let url = `${API_BASE_URL}/api/auth/zohoclientid`;
        if (selectedClient) {
          url += `/${selectedClient}`;
        } else if (clientID) {
          // Fallback to original clientID if no selectedClient
          url += `/${clientID}`;
        } else {
          // Handle the case where neither selectedClient nor clientID is available
          console.error("No client ID available");
          setLoading(false);
          return;
        }

        const response = await fetch(url);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data: ZohoClient[] = await response.json();
        setZohoClient(data);
      } catch (error) {
        console.error("Error fetching zoho client id:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchZohoClient();
  }, [selectedClient, clientID]); // Add selectedClient to the dependency array

  const handleModelChange = async (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    const modelName = event.target.value;
    const selectedId = event.target.value;
    setSelectedZohoviewId(selectedId);
    if (selectedId) {
      await fetchAndDisplayEmailBodies(selectedId);
    }
  };

  const handleStart = () => {
    if (!selectedPrompt) return;

    setIsStarted(true);
    setIsPaused(false);
    stopRef.current = false;
    goToTab("Output");
  };

  const handlePauseResume = () => {
    if (isStarted) {
      if (isPaused) {
        // Only allow resume if pitch update is completed
        if (isPitchUpdateCompleted && !isProcessing) {
          setIsPaused(false);
          stopRef.current = false;
          setIsPitchUpdateCompleted(false); // Reset the completion status
          goToTab("Output");
        }
      } else {
        // Pause logic
        setIsPaused(true);
        stopRef.current = true;
      }
    }
  };

  const handleReset = () => {
    // Only allow reset if paused
    if (!isPaused) return;
    // Stop any ongoing generation process
    stopRef.current = true;

    // Reset all state variables
    setIsStarted(false);
    setIsPaused(false);
    setIsProcessing(false);
    setIsPitchUpdateCompleted(false);

    // Reset last processed token and index
    setLastProcessedToken(null);
    setLastProcessedIndex(0);

    // Clear all accumulated data
    setAllResponses([]);
    setallsearchResults([]);
    seteveryscrapedData([]);
    setallprompt([]);
    setallSearchTermBodies([]);
    setallsummery([]);

    // Reset output form
    setOutputForm({
      generatedContent: "",
      linkLabel: "",
      usage: "",
      currentPrompt: "",
      searchResults: [],
      allScrapedData: "",
    });

    // Clear any existing content
    clearContentFunction?.();

    // Reset cost and request tracking variables
    cost = 0;
    failedReq = 0;
    successReq = 0;
    scrapfailedreq = 0;
    totaltokensused = 0;

    // Reset existingResponse and related index in Output.tsx
    clearExistingResponse(); // Call the function to clear existingResponse
    setCurrentIndex(0); // Reset currentIndex in Output.tsx
    setCurrentPage(0); // Resetting the current page to 0
  };

  // Get the demo account status directly from session storage
  const isDemoAccount = sessionStorage.getItem("isDemoAccount") === "true";

  // Set default delay for demo users
  // Set default delay for demo users
  useEffect(() => {
    if (isDemoAccount) {
      setDelay(5); // Set default delay value for demo users
      // Set overwriteDatabase to false for demo users:
      setSettingsForm((prev: SettingsFormType) => ({
        ...prev,
        overwriteDatabase: false, // Set default value for demo users
      }));
    }
  }, [isDemoAccount]);

  return (
    <div className="login-container pitch-page flex-col d-flex">
      <Header connectTo={true} />
      <div className="d-flex justify-between main-head tab-head">
        <div className="d-flex align-center justify-between full-width inner">
          <div className="tabs">
            <ul className="d-flex">
              <li>
                <button
                  onClick={tabHandler}
                  className={`button ${tab === "Template" ? "active" : ""}`}
                  title="Click to view the original non-personalized email template"
                >
                  Template
                </button>
              </li>
              <li>
                <button
                  onClick={tabHandler}
                  className={`button ${tab === "Output" ? "active" : ""}`}
                  title="Click to view the hyper-personalized emails being generated"

                >
                  Output
                </button>
              </li>
              <li>
                <button
                  onClick={tabHandler}
                  className={`button ${tab === "Mail" ? "active" : ""}`}
                >
                  Mail
                </button>
              </li>
              {userRole === "ADMIN" && (
                <li>
                  <button
                    onClick={tabHandler}
                    className={`button ${tab === "Settings" ? "active" : ""}`}
                  >
                    Settings
                  </button>
                </li>
              )}
            </ul>
          </div>
          <div className="button-group justify-start mb-0 full-width-1200">
            <div className="d-flex justify-start align-center radio-group flex-col-768">
              <div className="row mb-2">
                <div className="col">
                  {userRole === "ADMIN" && (
                    <div className="form-group d-flex align-center mb-0 ml-10  mr-10">
                      <label className="font-size-medium font-500 mb-0 mr-10 nowrap">
                        Select Client:
                      </label>
                      <select
                        value={selectedClient}
                        onChange={handleClientChange}
                        className="height-35 max-width-200"
                      >
                        <option value="">--Please choose a client--</option>
                        {clientNames.map((client: Client, index: number) => (
                          <option key={index} value={client.clientID}>
                            {`${client.firstName} ${client.lastName} - ${client.companyName} - ${client.clientID}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              </div>
              <div className="d-flex mt-10-768">
                {/* Add the checkbox here */}
                {!isDemoAccount && (
                  <div className="row mb-2">
                    <div className="col align-center d-flex">
                      <div className="options checkbox-options">
                        <ul className="d-flex row">
                          <li className="col">
                            <label>
                              <input
                                type="checkbox"
                                checked={settingsForm.overwriteDatabase}
                                name="overwriteDatabase"
                                id="overwriteDatabase"
                                onChange={settingsFormHandler}
                              />
                              <span>Overwrite database</span>
                            </label>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                {!isDemoAccount && (
                  <div className="form-group d-flex align-center mb-0">
                    <label className="font-size-medium font-500 ml-5 mb-0 mr-10">
                      Delay(secs)
                    </label>
                    <input
                      type="number"
                      value={delayTime}
                      onChange={(e: any) => setDelay(e.target.value)}
                      className="height-35"
                    />
                  </div>
                )}

                {!isStarted ? (
                  <button
                    className="action-button button ml-10"
                    onClick={handleStart}
                    disabled={!selectedPrompt?.name || !selectedZohoviewId}
                    title="Click to generate hyper-personalized emails using the selected template for contacts in the selected data file"
                  >
                    Start
                  </button>
                ) : (
                  <>
                    <button
                      className="action-button button ml-10"
                      onClick={handlePauseResume}
                      disabled={
                        isPaused && (!isPitchUpdateCompleted || isProcessing)
                      }
                      title={
                        isPaused
                          ? "Click to resume the generation of emails"
                          : "Click to pause the generation of emails"
                      }
                    >
                      {isPaused ? "Resume" : "Pause"}
                    </button>

                    <button
                      className="reset-button button ml-5"
                      onClick={handleReset}
                      disabled={
                        !isPitchUpdateCompleted || isProcessing || !isPaused
                      }
                      title="Click to reset so that the generation of emails begins again from the first of the contacts in the selected data file"
                    >
                      Reset
                    </button>
                  </>
                )}
              </div>
              {/* Stop Confirmation Popup */}
              {showPopup && (
                <div className="popup">
                  <p>Do you want to stop the process?</p>
                  <button onClick={() => handlePopupResponse(true)}>Yes</button>
                  <button onClick={() => handlePopupResponse(false)}>No</button>
                </div>
              )}
            </div>
            {/* <button className="action-button button">Generate pitch</button> */}
          </div>
        </div>
      </div>
      {tab === "Template" && (
        <div className="login-box gap-down d-flex">
          <div className="input-section edit-section">
            <div className="row flex-col-767">
              <div className="col col-4  col-12-640">
                <div className="form-group">
                  <label>
                  Original non-personalized email templates <span className="required">*</span>
                  </label>
                  <select
                    onChange={handleSelectChange}
                    value={selectedPrompt?.name || ""}
                    className={
                      !selectedPrompt?.name ? "highlight-required" : ""
                    }
                  >
                    <option value="">Please select a template</option>
                    {promptList.map((prompt: Prompt) => (
                      <option key={prompt.id} value={prompt.name}>
                        {prompt.name}
                      </option>
                    ))}
                  </select>
                  {!selectedPrompt?.name && (
                    <small className="error-text">
                      Please select a template
                    </small>
                  )}
                </div>
              </div>
              <div className="col col-4 col-12-640">
                
                <div className="form-group">
                  <label>
                  Data files of contacts <span className="required">*</span>
                  </label>
                  <select
                    name="model"
                    id="model"
                    onChange={handleZohoModelChange}
                    value={selectedZohoviewId}
                    className={!selectedZohoviewId ? "highlight-required" : ""}
                  >
                    <option value="">Please select a data file</option>
                    {zohoClient.map((val) => (
                      <option key={val.id} value={val.zohoviewId}>
                        {val.zohoviewName}
                      </option>
                    ))}
                  </select>
                  {!selectedZohoviewId && (
                    <small className="error-text">
                      Please select a data file
                    </small>
                  )}
                </div>

                {emailLoading && (
                  <div className="loader-overlay">
                    <div className="loader"></div>
                  </div>
                )}
              </div>

              <div className="col col-4  col-12-640">
                <div className="form-group">
                  <label>Language</label>
                  <select
                    onChange={handleLanguageChange}
                    value={selectedLanguage}
                  >
                    <option value="">Select a language</option>
                    {Object.values(Languages)
                      .sort((a, b) => a.localeCompare(b)) // Sort languages alphabetically
                      .map((language, index) => (
                        <option key={index} value={language}>
                          {language}
                        </option>
                      ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-12 col">
                {userRole === "ADMIN" && (
                  <div className="tabs secondary d-flex justify-between-991 flex-col-768 bb-0-768">
                    <ul className="d-flex bb-1-768">
                      <li>
                        <button
                          type="button"
                          onClick={tabHandler2}
                          className={`button ${
                            tab2 === "Template" ? "active" : ""
                          }`}
                        >
                          Template
                        </button>
                      </li>

                      <li>
                        <button
                          type="button"
                          onClick={tabHandler2}
                          className={`button ${
                            tab2 === "Instructions" ? "active" : ""
                          }`}
                        >
                          Instructions
                        </button>
                      </li>
                    </ul>
                    <div className="d-flex align-self ml-10 ml-768-0 mt-10-768 flex-col-480 full-width">
                      <button
                        className={`save-button button justify-center small d-flex align-center button-full-width-480 mb-10-480 ${
                          selectedPrompt?.name !== "Select a prompt"
                            ? ""
                            : "disabled" // Simplified conditional
                        }`}
                        disabled={
                          !selectedPrompt?.name ||
                          selectedPrompt?.name === "Select a prompt"
                        }
                        onClick={() => {
                          handleModalOpen("modal-edit-prompt");
                          setEditHandler();
                        }} // Improved disabled logic
                      >
                        <span>Edit prompt</span>
                      </button>
                      <span className="d-flex justify-right ml-10 ml-0-480 ">
                        <Modal
                          show={openModals["modal-add-prompt"]}
                          closeModal={() =>
                            handleModalClose("modal-add-prompt")
                          }
                          buttonLabel="Close"
                        >
                          <form
                            onSubmit={addPromptSubmitHandler}
                            className="full-height"
                          >
                            <h2 className="left">Add a prompt</h2>
                            <div className="form-group">
                              <label>Prompt name</label>
                              <input
                                type="text"
                                name="promptName"
                                placeholder="Enter prompt name"
                                value={addPrompt.promptName}
                                onChange={addPromptHandler}
                              />
                            </div>

                            {userRole === "ADMIN" && (
                              <div className="tabs secondary">
                                <ul className="d-flex">
                                  <li>
                                    <button
                                      type="button"
                                      onClick={tabHandler4}
                                      className={`button ${
                                        tab4 === "Template" ? "active" : ""
                                      }`}
                                    >
                                      Template
                                    </button>
                                  </li>

                                  <li>
                                    <button
                                      type="button"
                                      onClick={tabHandler4}
                                      className={`button ${
                                        tab4 === "Instructions" ? "active" : ""
                                      }`}
                                    >
                                      Instructions
                                    </button>
                                  </li>
                                </ul>
                              </div>
                            )}
                            {tab4 === "Template" && (
                              <div className="form-group edit-prompt-form-height">
                                <label>Template</label>
                                <span className="pos-relative">
                                  <ReactQuill
                                    className="adjust-quill-height"
                                    theme="snow"
                                    value={
                                      addPrompt?.promptTemplate
                                        ? formatTextForDisplay(
                                            addPrompt?.promptTemplate
                                          )
                                        : ""
                                    }
                                    defaultValue={addPrompt?.promptTemplate}
                                    onChange={(value: string) =>
                                      handleAddPromptTemplateRTE(
                                        formatTextForEditor(value)
                                      )
                                    }
                                    modules={modules}
                                  />
                                </span>
                              </div>
                            )}
                            {tab4 === "Instructions" &&
                              userRole === "ADMIN" && (
                                <div className="form-group edit-prompt-form-height">
                                  <label>Instructions</label>
                                  <span className="pos-relative">
                                    <ReactQuill
                                      className="adjust-quill-height"
                                      theme="snow"
                                      value={
                                        addPrompt?.promptInput
                                          ? formatTextForDisplay(
                                              addPrompt?.promptInput
                                            )
                                          : ""
                                      }
                                      defaultValue={addPrompt?.promptInput}
                                      onChange={(value: string) =>
                                        handleAddPromptInPutRTE(
                                          formatTextForEditor(value)
                                        )
                                      }
                                      modules={modules}
                                    />
                                  </span>
                                </div>
                              )}

                            <div className="form-group d-flex">
                              <button
                                type="submit"
                                className="action-button button mr-10"
                              >
                                Save prompt
                              </button>
                              {addPromptAlert && (
                                <span className="alert alert-success ml-10">
                                  Prompt added successfully.
                                </span>
                              )}
                            </div>
                          </form>
                        </Modal>
                        <button
                          className="save-button button small d-flex justify-between align-center button-full-width-480"
                          onClick={() => handleModalOpen("modal-add-prompt")}
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="#FFFFFF"
                            viewBox="0 0 30 30"
                            width="22px"
                            height="22px"
                          >
                            <path d="M15,3C8.373,3,3,8.373,3,15c0,6.627,5.373,12,12,12s12-5.373,12-12C27,8.373,21.627,3,15,3z M21,16h-5v5 c0,0.553-0.448,1-1,1s-1-0.447-1-1v-5H9c-0.552,0-1-0.447-1-1s0.448-1,1-1h5V9c0-0.553,0.448-1,1-1s1,0.447,1,1v5h5 c0.552,0,1,0.447,1,1S21.552,16,21,16z" />
                          </svg>
                          <span className="ml-5">Add a prompt</span>
                        </button>
                        <button
                          className="secondary button small d-flex justify-between align-center ml-10 button-full-width-480"
                          //onClick={deletePromptHandler}
                          disabled={
                            !selectedPrompt?.name ||
                            selectedPrompt?.name === "Select a prompt"
                          }
                          onClick={() =>
                            handleModalOpen("modal-confirm-delete")
                          }
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="#FFFFFF"
                            viewBox="0 0 50 50"
                            width="18px"
                            height="18px"
                            style={{ position: "relative", marginTop: "-2px" }}
                          >
                            <path d="M 21 2 C 19.354545 2 18 3.3545455 18 5 L 18 7 L 8 7 A 1.0001 1.0001 0 1 0 8 9 L 9 9 L 9 45 C 9 46.654 10.346 48 12 48 L 38 48 C 39.654 48 41 46.654 41 45 L 41 9 L 42 9 A 1.0001 1.0001 0 1 0 42 7 L 32 7 L 32 5 C 32 3.3545455 30.645455 2 29 2 L 21 2 z M 21 4 L 29 4 C 29.554545 4 30 4.4454545 30 5 L 30 7 L 20 7 L 20 5 C 20 4.4454545 20.445455 4 21 4 z M 19 14 C 19.552 14 20 14.448 20 15 L 20 40 C 20 40.553 19.552 41 19 41 C 18.448 41 18 40.553 18 40 L 18 15 C 18 14.448 18.448 14 19 14 z M 25 14 C 25.552 14 26 14.448 26 15 L 26 40 C 26 40.553 25.552 41 25 41 C 24.448 41 24 40.553 24 40 L 24 15 C 24 14.448 24.448 14 25 14 z M 31 14 C 31.553 14 32 14.448 32 15 L 32 40 C 32 40.553 31.553 41 31 41 C 30.447 41 30 40.553 30 40 L 30 15 C 30 14.448 30.447 14 31 14 z" />
                          </svg>
                          <span className="ml-5">Delete prompt</span>
                        </button>
                        <Modal
                          show={openModals["modal-confirm-delete"]}
                          closeModal={() =>
                            handleModalClose("modal-confirm-delete")
                          }
                          buttonLabel=""
                          size="auto-width"
                        >
                          <h3 className="center text-center mt-0">
                            Are you sure want to delete?
                          </h3>
                          <div className="button-group mb-0 d-flex justify-center">
                            <button
                              className="button save-button small"
                              onClick={deletePromptHandler}
                            >
                              Yes
                            </button>
                            <button
                              className="button button secondary small ml-5"
                              onClick={() =>
                                handleModalClose("modal-confirm-delete")
                              }
                            >
                              No
                            </button>
                          </div>
                        </Modal>
                      </span>
                    </div>
                  </div>
                )}
                {tab2 === "Template" && (
                  <div className="form-group">
                    <label>Template</label>
                    <span className="pos-relative">
                      <pre
                        className={`no-content height-400 ql-editor ${
                          !selectedPrompt?.template ? "text-light" : ""
                        }`}
                        dangerouslySetInnerHTML={{
                          __html:
                            selectedPrompt?.template ??
                            "Template will appear here",
                        }}
                      ></pre>

                      <Modal
                        show={openModals["modal-addInput"]}
                        closeModal={() => handleModalClose("modal-addInput")}
                        buttonLabel="Ok"
                      >
                        <label>Template</label>
                        <ReactQuill
                          theme="snow"
                          className="adjust-quill-height"
                          value={
                            selectedPrompt
                              ? formatTextForDisplay(selectedPrompt.text)
                              : ""
                          }
                          defaultValue={selectedPrompt?.text}
                          onChange={(value: string) =>
                            handleViewPromptRTE(formatTextForEditor(value))
                          }
                          modules={modules}
                        />
                      </Modal>
                      <button
                        className="full-view-icon d-flex align-center justify-center"
                        type="button"
                        onClick={() => handleModalOpen("modal-addInput")}
                      >
                        <svg width="40px" height="40px" viewBox="0 0 512 512">
                          <polyline
                            points="304 96 416 96 416 208"
                            fill="none"
                            stroke="#000000"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="32"
                          />
                          <line
                            x1="405.77"
                            y1="106.2"
                            x2="111.98"
                            y2="400.02"
                            fill="none"
                            stroke="#000000"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="32"
                          />
                          <polyline
                            points="208 416 96 416 96 304"
                            fill="none"
                            stroke="#000000"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="32"
                          />
                        </svg>
                      </button>
                    </span>
                  </div>
                )}
                {tab2 === "Instructions" && userRole === "ADMIN" && (
                  <div className="form-group">
                    <label>Instructions</label>
                    <span className="pos-relative">
                      <pre
                        className={`no-content height-400 ql-editor ${
                          !selectedPrompt?.text ? "text-light" : ""
                        }`}
                        dangerouslySetInnerHTML={{
                          __html:
                            selectedPrompt?.text ?? "Template will appear here",
                        }}
                      ></pre>

                      <Modal
                        show={openModals["modal-addInput"]}
                        closeModal={() => handleModalClose("modal-addInput")}
                        buttonLabel="Ok"
                      >
                        <label>Instructions</label>
                        <ReactQuill
                          theme="snow"
                          className="adjust-quill-height"
                          value={
                            selectedPrompt
                              ? formatTextForDisplay(selectedPrompt.text)
                              : ""
                          }
                          defaultValue={selectedPrompt?.text}
                          onChange={(value: string) =>
                            handleViewPromptRTE(formatTextForEditor(value))
                          }
                          modules={modules}
                        />
                      </Modal>
                      <button
                        className="full-view-icon d-flex align-center justify-center"
                        type="button"
                        onClick={() => handleModalOpen("modal-addInput")}
                      >
                        <svg width="40px" height="40px" viewBox="0 0 512 512">
                          <polyline
                            points="304 96 416 96 416 208"
                            fill="none"
                            stroke="#000000"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="32"
                          />
                          <line
                            x1="405.77"
                            y1="106.2"
                            x2="111.98"
                            y2="400.02"
                            fill="none"
                            stroke="#000000"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="32"
                          />
                          <polyline
                            points="208 416 96 416 96 304"
                            fill="none"
                            stroke="#000000"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="32"
                          />
                        </svg>
                      </button>
                    </span>
                  </div>
                )}
                <div className="form-group d-flex justify-between mb-0">
                  <Modal // Edit Prompt Modal
                    show={openModals["modal-edit-prompt"]}
                    closeModal={() => handleModalClose("modal-edit-prompt")}
                    buttonLabel="Close"
                  >
                    <form
                      onSubmit={editPromptSubmitHandler}
                      className="full-height"
                    >
                      <h2 className="left">Edit Prompt</h2>
                      <div className="form-group">
                        <label>Prompt name</label>
                        <input
                          type="text"
                          name="promptName"
                          placeholder="Enter prompt name"
                          value={editPrompt?.promptName}
                          onChange={editPromptHandler}
                        />
                      </div>

                      {userRole === "ADMIN" && (
                        <div className="tabs secondary">
                          <ul className="d-flex">
                            <li>
                              <button
                                type="button"
                                onClick={tabHandler3}
                                className={`button ${
                                  tab3 === "Template" ? "active" : ""
                                }`}
                              >
                                Template
                              </button>
                            </li>

                            <li>
                              <button
                                type="button"
                                onClick={tabHandler3}
                                className={`button ${
                                  tab3 === "Instructions" ? "active" : ""
                                }`}
                              >
                                Instructions
                              </button>
                            </li>
                          </ul>
                        </div>
                      )}
                      {tab3 === "Template" && (
                        <div className="form-group edit-prompt-form-height">
                          <label>Template</label>
                          <span className="pos-relative">
                            <ReactQuill
                              className="height-350 adjust-quill-height"
                              theme="snow"
                              value={
                                editPrompt?.promptTemplate
                                  ? formatTextForDisplay(
                                      editPrompt?.promptTemplate
                                    )
                                  : ""
                              }
                              defaultValue={editPrompt?.promptTemplate}
                              onChange={(value: string) =>
                                handleEditPromptTemplateRTE(
                                  formatTextForEditor(value)
                                )
                              }
                              modules={modules}
                            />
                          </span>
                        </div>
                      )}
                      {tab3 === "Instructions" && userRole === "ADMIN" && (
                        <div className="form-group edit-prompt-form-height">
                          <label>Instructions</label>
                          <span className="pos-relative">
                            <ReactQuill
                              className="height-350 adjust-quill-height"
                              theme="snow"
                              value={
                                editPrompt?.promptInput
                                  ? formatTextForDisplay(
                                      editPrompt?.promptInput
                                    )
                                  : ""
                              }
                              defaultValue={editPrompt?.promptInput}
                              onChange={(value: string) =>
                                handleEditPromptInputRTE(
                                  formatTextForEditor(value)
                                )
                              }
                              modules={modules}
                            />
                          </span>
                        </div>
                      )}
                      <div className="form-group d-flex">
                        <button
                          type="submit"
                          className="action-button button mr-10"
                        >
                          Save changes
                        </button>
                        {editPromptAlert && (
                          <span className="alert alert-success ml-10">
                            Prompt edited successfully.
                          </span>
                        )}
                      </div>
                    </form>
                  </Modal>
                  {/* Form Buttons */}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === "Settings" && userRole === "ADMIN" && (
        <Settings
          settingsForm={settingsForm}
          settingsFormHandler={settingsFormHandler}
          settingsFormOnSubmit={settingsFormOnSubmit}
          searchTermForm={searchTermForm}
          searchTermFormHandler={searchTermFormHandler}
          searchTermFormOnSubmit={searchTermFormOnSubmit}
          selectedClient={selectedClient}
          fetchClientSettings={fetchClientSettings}
        />
      )}

      {tab === "Output" && (
        <>
          <Output
            outputForm={outputForm}
            outputFormHandler={outputFormHandler}
            setOutputForm={setOutputForm}
            allResponses={allResponses}
            isPaused={isPaused}
            setAllResponses={setAllResponses}
            currentIndex={currentIndex}
            setCurrentIndex={setCurrentIndex}
            //onOutputChange={outputFormHandler}
            onClearOutput={clearOutputForm}
            allprompt={allprompt}
            setallprompt={setallprompt}
            allsearchResults={allsearchResults}
            setallsearchResults={setallsearchResults}
            everyscrapedData={everyscrapedData}
            seteveryscrapedData={seteveryscrapedData}
            allSearchTermBodies={allSearchTermBodies}
            setallSearchTermBodies={setallSearchTermBodies}
            onClearContent={handleClearContent}
            setallsummery={setallsummery}
            allsummery={allsummery}
            existingResponse={existingResponse}
            setexistingResponse={setexistingResponse}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            prevPageToken={prevPageToken}
            nextPageToken={nextPageToken}
            fetchAndDisplayEmailBodies={fetchAndDisplayEmailBodies}
            selectedZohoviewId={selectedZohoviewId}
            onClearExistingResponse={setClearExistingResponse}
            isResetEnabled={!isProcessing} // Pass isResetEnabled as a separate prop
            zohoClient={zohoClient} // Add this new prop
          />
        </>
      )}

{tab === "Mail" && (
        <>
          <Mail
              settingsForm={settingsForm}
              settingsFormHandler={settingsFormHandler}
              settingsFormOnSubmit={settingsFormOnSubmit}
              searchTermForm={searchTermForm}
              searchTermFormHandler={searchTermFormHandler}
              searchTermFormOnSubmit={searchTermFormOnSubmit}
              selectedClient={selectedClient} 
              fetchClientSettings={fetchClientSettings}   
          />
        </>
      )}

    </div>
  );
};

export default MainPage;
