import { useState, useEffect } from "react";
import Modal from "../common/Modal";
import { copyToClipboard } from "../../utils/utils";
import previousIcon from '../../assets/images/previous.png';
import nextIcon from '../../assets/images/Next.png';
import singleprvIcon from '../../assets/images/SinglePrv.png'
import singlenextIcon from '../../assets/images/SingleNext.png'
import * as XLSX from 'xlsx'; // Add this import
import FileSaver from 'file-saver'; // Correct import syntax



// In Output.tsx
interface ZohoClient {
  id: number;
  zohoviewId: string;
  zohoviewName: string;
  clientId: number;
  totalContact: number;
}

interface OutputInterface {
  outputForm: {
    generatedContent: string;
    linkLabel: string;
    usage: string;
    currentPrompt: string;
    searchResults: string[];
    allScrapedData: string;
  };
  isResetEnabled: boolean; // Add this prop

  outputFormHandler: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  setOutputForm: React.Dispatch<
    React.SetStateAction<{
      generatedContent: string;
      linkLabel: string;
      usage: string;
      currentPrompt: string;
      searchResults: string[];
      allScrapedData: string;
    }>
  >;
  allResponses: any[];
  isPaused: boolean;
  setAllResponses: React.Dispatch<React.SetStateAction<any[]>>; // Add this line
  currentIndex: number; // Add this line
  setCurrentIndex: React.Dispatch<React.SetStateAction<number>>; // Add this line
  onClearOutput: () => void;
  allprompt: any[];
  setallprompt: React.Dispatch<React.SetStateAction<any[]>>;
  allsearchResults: any[];
  setallsearchResults: React.Dispatch<React.SetStateAction<any[]>>;
  everyscrapedData: any[];
  seteveryscrapedData: React.Dispatch<React.SetStateAction<any[]>>;
  allSearchTermBodies: string[];
  setallSearchTermBodies: React.Dispatch<React.SetStateAction<string[]>>;
  onClearContent?: (clearContent: () => void) => void; // Add this line
  allsummery: any[];
  setallsummery: React.Dispatch<React.SetStateAction<any[]>>;
  existingResponse: any[];
  setexistingResponse: React.Dispatch<React.SetStateAction<any[]>>;
  currentPage: number;
  setCurrentPage: React.Dispatch<React.SetStateAction<number>>;
  prevPageToken: string | null;
  nextPageToken: string | null;
  fetchAndDisplayEmailBodies: (
    zohoviewId: string,
    pageToken?: string | null,
    direction?: "next" | "previous" | null
  ) => Promise<void>;
  selectedZohoviewId: string;
  onClearExistingResponse?: (clearFunction: () => void) => void; // Define the prop to accept a function
  zohoClient: ZohoClient[]; // Add this new prop type
}

const Output: React.FC<OutputInterface> = ({
  outputForm,
  outputFormHandler,
  setOutputForm,
  allResponses,
  isPaused,
  setAllResponses,
  currentIndex,
  setCurrentIndex,
  onClearOutput,
  allprompt,
  setallprompt,
  allsearchResults,
  setallsearchResults,
  everyscrapedData,
  seteveryscrapedData,
  allSearchTermBodies,
  setallSearchTermBodies,
  onClearContent, // Add this line
  allsummery,
  setallsummery,
  existingResponse,
  setexistingResponse,
  currentPage,
  setCurrentPage,
  prevPageToken,
  nextPageToken,
  fetchAndDisplayEmailBodies,
  selectedZohoviewId,
  onClearExistingResponse,
  isResetEnabled, // Receive the prop
  zohoClient, // Add this to the destructured props
}) => {
  const [isCopyText, setIsCopyText] = useState(false);

  const copyToClipboardHandler = async () => {
    const contentToCopy = combinedResponses[currentIndex]?.pitch || "";

    if (contentToCopy) {
      try {
        // Use the existing copyToClipboard utility function
        const copied = await copyToClipboard(contentToCopy);
        setIsCopyText(copied);

        // Reset the copied state after 1 second
        setTimeout(() => {
          setIsCopyText(false);
        }, 1000);
      } catch (err) {
        console.error("Error copying text:", err);
      }
    }
  };

  const formatOutput = (text: string) => {
    return text
      .replace(
        /successfully generated/gi,
        '<span style="color: green;">successfully generated</span>'
      )
      .replace(/error/gi, '<span style="color: red;">error</span>');
  };
  const [openModals, setOpenModals] = useState<{ [key: string]: boolean }>({});

  const handleModalOpen = (id: string) => {
    setOpenModals((prev) => ({ ...prev, [id]: true }));
  };

  const handleModalClose = (id: string) => {
    setOpenModals((prev) => ({ ...prev, [id]: false }));
  };

  const [tab, setTab] = useState("New");
  const tabHandler = (e: React.ChangeEvent<any>) => {
    const { innerText } = e.target;
    console.log(innerText, "innerText");
    setTab(innerText);
  };

  const [tab2, setTab2] = useState("Output");
  const tabHandler2 = (e: React.ChangeEvent<any>) => {
    const { innerText } = e.target;
    console.log(innerText, "innerText");
    setTab2(innerText);
  };

  const [emailLoading, setEmailLoading] = useState(false); // Loading state for fetching email data

  const [tab3, setTab3] = useState("Current prompt");
  const tabHandler3 = (e: React.ChangeEvent<any>) => {
    const { innerText } = e.target;
    console.log(innerText, "innerText");
    setTab3(innerText);
  };

  const clearContent = () => {
    setOutputForm((prevOutputForm: any) => ({
      ...prevOutputForm,
      generatedContent: "", // Clear generated content
      linkLabel: "", // Clear link label
      currentPrompt: "",
      searchResults: [],
      allScrapedData: "",
    }));
    setAllResponses([]); // Clear all responses
    setCurrentIndex(0); // Reset current index to 0
    setallprompt([]); // Clear all prompts
    setallsearchResults([]); // Clear all search results
    seteveryscrapedData([]); // Clear all scraped data
    setallSearchTermBodies([]); // Clear all search term bodies
    setallsummery([]);
    setCombinedResponses([]); //Clear allCombinedResponses
    setCombinedResponses([]); // Clear combinedResponses
    setexistingResponse([]);
    setExistingDataIndex(0);
    setCurrentIndex(0); // Use the prop to reset currentIndex
    setCurrentPage(0); // Resetting the
  };

  const [userRole, setUserRole] = useState<string>(""); // Store user role

  useEffect(() => {
    const isAdminString = sessionStorage.getItem("isAdmin");
    const isAdmin = isAdminString === "true"; // Correct comparison
    setUserRole(isAdmin ? "ADMIN" : "USER");
  }, []);

  useEffect(() => {
    if (onClearContent) {
      onClearContent(clearContent);
    }
  }, [onClearContent]);

  const [existingDataIndex, setExistingDataIndex] = useState(0);

  useEffect(() => {
    if (onClearExistingResponse) {
      onClearExistingResponse(() => clearExistingResponse);
    }
  }, [onClearExistingResponse]);

  const clearExistingResponse = () => {
    setexistingResponse([]); // Clear the existingResponse state
    setExistingDataIndex(0); // Reset the index
  };

  useEffect(() => {
    // Keep currentIndex as is when new responses are added
    if (currentIndex >= combinedResponses.length) {
      setCurrentIndex(combinedResponses.length - 1);
    }
  }, [allResponses, currentIndex, setCurrentIndex]);

  const clearUsage = () => {
    setOutputForm((prevOutputForm: any) => ({
      ...prevOutputForm,
      usage: "", // Correctly clears the usage field
    }));
  };

  // useEffect(() => {
  //   // Set to the last response when new responses are added
  //   if (combinedResponses.length > 0) {
  //     setCurrentIndex(combinedResponses.length - 1);
  //   }
  // }, [allResponses, setCurrentIndex]);

  const [combinedResponses, setCombinedResponses] = useState<any[]>([]);

  useEffect(() => {
    // Prioritize allResponses, then add unique existingResponses
    let newCombinedResponses = [...allResponses]; // Start with fresh responses

    existingResponse.forEach((existing) => {
      if (!newCombinedResponses.find((nr) => nr.id === existing.id)) {
        newCombinedResponses.push(existing);
      }
    });

    setCombinedResponses(newCombinedResponses);
  }, [allResponses, existingResponse]);

  useEffect(() => {
    if (
      combinedResponses.length > 0 &&
      combinedResponses[combinedResponses.length - 1]?.nextPageToken
    ) {
      setCurrentIndex(combinedResponses.length - 1);
    }
  }, [combinedResponses]);

  const handleNextPage = async () => {
    if (currentIndex < combinedResponses.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      const lastItem = combinedResponses[combinedResponses.length - 1];
      if (lastItem?.nextPageToken) {
        setEmailLoading(true);
        try {
          await fetchAndDisplayEmailBodies(
            selectedZohoviewId,
            lastItem.nextPageToken,
            "next"
          );
          setCurrentIndex(combinedResponses.length);
        } finally {
          setEmailLoading(false);
        }
      }
    }
  };

  const handlePrevPage = async () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    } else {
      const firstItem = combinedResponses[0];
      if (firstItem?.prevPageToken) {
        setEmailLoading(true);
        try {
          await fetchAndDisplayEmailBodies(
            selectedZohoviewId,
            firstItem.prevPageToken,
            "previous"
          );
          // No need to update currentIndex here, as prepending maintains the current item's position
        } finally {
          setEmailLoading(false);
        }
      }
    }
  };


  const handleFirstPage = () => {
    setCurrentIndex(0);
  };
  
  const handleLastPage = () => {
    setCurrentIndex(combinedResponses.length - 1);
  };


  // Add this state to track the input value separately from the currentIndex
  const [inputValue, setInputValue] = useState<string>(
    (currentIndex + 1).toString()
  );

  // Update inputValue whenever currentIndex changes
  useEffect(() => {
    setInputValue((currentIndex + 1).toString());
  }, [currentIndex]);

  const handleIndexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;

    // Always update the input field value
    setInputValue(newValue);

    // Only update the actual index if we have a valid number
    if (newValue.trim() !== "") {
      const pageNumber = parseInt(newValue, 10);

      if (!isNaN(pageNumber) && pageNumber > 0) {
        // Ensure it doesn't exceed the maximum
        const validPageNumber = Math.min(pageNumber, combinedResponses.length);

        // Convert to zero-based index
        setCurrentIndex(validPageNumber - 1);
      }
    } else {
      // If input is cleared, default to index 0 (first item)
      setCurrentIndex(0);
    }
  };

  const [isExporting, setIsExporting] = useState(false);

  // Add this function inside your component
const exportToExcel = () => {
  if (!combinedResponses || combinedResponses.length === 0) {
    alert("No data available to export");
    return;
  }
  
  try {
    setIsExporting(true);
    console.log("Exporting data:", combinedResponses.length, "records");
    
    // Format the data for Excel - extract only the fields we want to include
    const exportData = combinedResponses.map(item => ({
      Name: item.name || item.full_Name || 'N/A',
      Title: item.title || item.job_Title || 'N/A',
      Company: item.company || item.account_name_friendlySingle_Line_12 || 'N/A',
      Location: item.location || item.mailing_Country || 'N/A',
      Website: item.website || 'N/A',
      LinkedIn: item.linkedin || item.linkedIn_URL || 'N/A',
      Pitch: item.pitch || item.sample_email_body || 'N/A',
      Timestamp: item.timestamp || new Date().toISOString(),
      Generated: item.generated ? 'Yes' : 'No'
    }));
    
    // Create worksheet with the data
    const ws = XLSX.utils.json_to_sheet(exportData);
    
    // Add column widths for better readability
    const wscols = [
      { wch: 20 }, // Name
      { wch: 20 }, // Title
      { wch: 20 }, // Company
      { wch: 15 }, // Location
      { wch: 25 }, // Website
      { wch: 25 }, // LinkedIn
      { wch: 60 }, // Pitch
      { wch: 20 }, // Timestamp
      { wch: 10 }, // Generated
    ];
    ws['!cols'] = wscols;
    
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Generated Pitches");
    
    // Generate a filename with date
    const date = new Date().toISOString().split('T')[0];
    const filename = `Generated_Pitches_${date}.xlsx`;
    
    // Attempt to download the file
    try {
      // Try the standard XLSX.writeFile method first
      XLSX.writeFile(wb, filename);
      console.log("Excel file exported with XLSX.writeFile");
    } catch (writeError) {
      console.warn("XLSX.writeFile failed, falling back to FileSaver:", writeError);
      
      // Fallback to FileSaver if writeFile doesn't work
      const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([wbout], { type: 'application/octet-stream' });
      FileSaver.saveAs(blob, filename);
      console.log("Excel file exported with FileSaver");
    }
  } catch (error) {
    console.error("Error exporting to Excel:", error);
    alert("Error exporting data. See console for details.");
  } finally {
    setIsExporting(false);
  }
};

useEffect(() => {
  console.table(combinedResponses);
}, [combinedResponses]);



useEffect(() => {
  sessionStorage.setItem('currentIndex', currentIndex.toString());
}, [currentIndex]);

useEffect(() => {
  const storedCurrentIndex = sessionStorage.getItem('currentIndex');
  if (storedCurrentIndex !== null) {
    setCurrentIndex(parseInt(storedCurrentIndex, 10));
  }
}, [setCurrentIndex]);


  return (
    <div className="login-box gap-down">
      {/* <div className="tabs secondary d-flex align-center"></div> */}
      {/* <h2 className="left">Output</h2> */}
      {userRole === "ADMIN" && (
        <div className="row pb-2 d-flex align-center justify-end">
          <div className="col col-12">
            <div className="form-group d-flex justify-between">
              <label className="mb-0">Usage</label>
            </div>
            <div className="form-group d-flex justify-between">
              <span className="pos-relative full-width">
                <textarea
                  placeholder="Usage"
                  rows={1}
                  name="tkUsage"
                  value={outputForm.usage}
                  className="full-width"
                  onChange={outputFormHandler}
                ></textarea>
              </span>
              <button
                className="ml-10 button clear-button small d-flex align-center h-[100%] justify-center"
                onClick={clearUsage}
                style={{ height: "40px" }}
              >
                Clear Usage
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Tab */}
      {tab === "New" && (
        <>
          <div className="tabs secondary d-flex align-center flex-col-991">
            <ul className="d-flex">
              {userRole === "ADMIN" && (
                <li>
                  <button
                    onClick={tabHandler2}
                    className={`button ${tab2 === "Output" ? "active" : ""}`}
                  >
                    Output
                  </button>
                </li>
              )}
              {userRole === "ADMIN" && (
                <li>
                  <button
                    onClick={tabHandler2}
                    className={`button ${
                      tab2 === "Current prompt" ? "active" : ""
                    }`}
                  >
                    Current prompt
                  </button>
                </li>
              )}
            </ul>
            <div className="d-flex flex-col-1200 mb-10-991 mt-10-991">
              <div className="d-flex mr-10 align-center">
                <button
                  onClick={handleFirstPage}
                  disabled={
                    !isResetEnabled ||
                    (currentIndex === 0 && !combinedResponses[0]?.prevPageToken)
                  }
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: "5px 10px",
                    backgroundColor: "#f0f0f0",
                    border: "1px solid #ccc",
                    borderRadius: "4px",
                    cursor: "pointer",
                  }}
                  title="Click to go to the first generated email"
                >
                  <img
                    src={previousIcon}
                    alt="Previous"
                    style={{
                      width: "20px",
                      height: "20px",
                      objectFit: "contain",
                      marginRight: "5px",
                    }}
                  />
                </button>
                <button
                  onClick={handlePrevPage}
                  disabled={
                    !isResetEnabled ||
                    (currentIndex === 0 && !combinedResponses[0]?.prevPageToken)
                  }
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: "5px 10px",
                    backgroundColor: "#f0f0f0",
                    border: "1px solid #ccc",
                    borderRadius: "4px",
                    cursor: "pointer",
                  }}
                  title="Click to go to the previous generated email"
                >
                  <img
                    src={singleprvIcon}
                    alt="Previous"
                    style={{
                      width: "20px",
                      height: "20px",
                      objectFit: "contain",
                      marginRight: "5px",
                    }}
                  />
                  <span>Prev</span>
                </button>

                <button
                  onClick={handleNextPage}
                  disabled={
                    !isResetEnabled ||
                    emailLoading ||
                    (currentIndex === combinedResponses.length - 1 &&
                      !combinedResponses[combinedResponses.length - 1]
                        ?.nextPageToken)
                  }
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: "5px 10px",
                    backgroundColor: "#f0f0f0",
                    border: "1px solid #ccc",
                    borderRadius: "4px",
                    cursor: "pointer",
                  }}
                  title="Click to go to the next generated email"
                >
                  <span>Next</span>
                  <img
                    src={singlenextIcon}
                    alt="Next"
                    style={{
                      width: "20px",
                      height: "20px",
                      objectFit: "contain",
                      marginLeft: "5px",
                    }}
                  />
                </button>

                <button
                  onClick={handleLastPage}
                  disabled={
                    !isResetEnabled ||
                    emailLoading ||
                    (currentIndex === combinedResponses.length - 1 &&
                      !combinedResponses[combinedResponses.length - 1]
                        ?.nextPageToken)
                  }
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: "5px 10px",
                    backgroundColor: "#f0f0f0",
                    border: "1px solid #ccc",
                    borderRadius: "4px",
                    cursor: "pointer",
                  }}
                  title="Click to go to the last generated email"
                >
                  <img
                    src={nextIcon}
                    alt="Next"
                    style={{
                      width: "20px",
                      height: "20px",
                      objectFit: "contain",
                      marginLeft: "5px",
                    }}
                  />
                </button>

                {emailLoading && (
                  <div className="loader-overlay">
                    <div className="loader"></div>
                  </div>
                )}
              </div>
              <div className="d-flex flex-col-768 mt-10-1200">
                <div className="text-center mt-2 d-flex align-center mr-20 mt-10-991 font-size-medium">
                  {combinedResponses.length > 0 && (
                    <>
                      <span>
                        Contact {currentIndex + 1} of{" "}
                        {
                          // Get total contacts from the selected view or all views
                          selectedZohoviewId
                            ? (() => {
                                const selectedView = zohoClient.find(
                                  (client) =>
                                    client.zohoviewId === selectedZohoviewId
                                );
                                return selectedView
                                  ? selectedView.totalContact
                                  : combinedResponses.length;
                              })()
                            : zohoClient.reduce(
                                (sum, client) => sum + client.totalContact,
                                0
                              )
                        }{" "}
                        ({combinedResponses.length} loaded)
                      </span>
                      <span style={{ whiteSpace: "pre" }}> </span>
                      <span style={{ whiteSpace: "pre" }}> </span>

                      {/* Input box to enter index */}
                      <input
                        type="number"
                        value={inputValue}
                        onChange={handleIndexChange}
                        onBlur={() => {
                          // When input loses focus, ensure it shows a valid value
                          if (
                            inputValue.trim() === "" ||
                            isNaN(parseInt(inputValue, 10))
                          ) {
                            setInputValue((currentIndex + 1).toString());
                          }
                        }}
                        className="form-control text-center mx-2"
                        style={{ width: "70px" }}
                      />
                    </>
                  )}
                </div>
                <div
                  className="contact-info mt-2 lh-35 align-center d-inline-block ml-10 mt-10-991 word-wrap--break-word word-break--break-all  ml-0-768"
                  style={{ color: "red" }}
                >
                  <strong style={{ whiteSpace: "pre" }}>Contact: </strong>
                  <span style={{ whiteSpace: "pre" }}> </span>
                  {combinedResponses[currentIndex]?.name || "NA"} |
                  <span style={{ whiteSpace: "pre" }}> </span>
                  {combinedResponses[currentIndex]?.title || "NA"} |
                  <span style={{ whiteSpace: "pre" }}> </span>
                  {combinedResponses[currentIndex]?.company || "NA"} |
                  <span style={{ whiteSpace: "pre" }}> </span>
                  {combinedResponses[currentIndex]?.location || "NA"} |
                  <span style={{ whiteSpace: "pre" }}> </span>
                  <a
                    href={
                      combinedResponses[currentIndex]?.website &&
                      !combinedResponses[currentIndex]?.website.startsWith(
                        "http"
                      )
                        ? `https://${combinedResponses[currentIndex]?.website}`
                        : combinedResponses[currentIndex]?.website
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {combinedResponses[currentIndex]?.website || "NA"}
                  </a>
                  <span style={{ whiteSpace: "pre" }}> </span>|
                  <span style={{ whiteSpace: "pre" }}> </span>
                  <a
                    href={combinedResponses[currentIndex]?.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    LinkedIn
                  </a>
                </div>
              </div>
            </div>
          </div>
          {tab2 === "Output" && (
            <>
              <div className="form-group">
                <div className="d-flex mb-10 align-items-center">
                  {userRole === "ADMIN" && (
                    <button
                      className="button clear-button small d-flex align-center"
                      onClick={clearContent}
                    >
                      <span>Clear output</span>
                    </button>
                  )}
                </div>

                {/* THIS MESSAGE MOVED HERE, ABOVE OUTPUT */}
                {isPaused && !isResetEnabled && (
                  <div
                    style={{
                      color: "red",
                      marginBottom: "8px",
                      fontWeight: 500,
                    }}
                  >
                    Please wait, the last pitch generation is being completed...
                    <span className="animated-ellipsis"></span>
                  </div>
                )}

                <span className="pos-relative">
                  <pre
                    className="w-full p-3 border border-gray-300 rounded-lg overflow-y-auto height-50"
                    dangerouslySetInnerHTML={{
                      __html: formatOutput(outputForm.generatedContent),
                    }}
                  ></pre>
                  <Modal
                    show={openModals["modal-output-1"]}
                    closeModal={() => handleModalClose("modal-output-1")}
                    buttonLabel="Ok"
                  >
                    <label>Output</label>
                    <pre
                      className="height-full--25 w-full p-3 border border-gray-300 rounded-lg overflow-y-auto textarea-height-600"
                      dangerouslySetInnerHTML={{
                        __html: formatOutput(outputForm.generatedContent),
                      }}
                    ></pre>
                  </Modal>
                </span>
              </div>
              <div className="form-group">
                <div className="d-flex mb-10 align-items-center">
                  {/* Your existing Copy to clipboard button */}
                  <button
                    className={`button d-flex align-center small ${
                      isCopyText && "save-button auto-width"
                    }`}
                    onClick={copyToClipboardHandler}
                  >
                    {isCopyText ? (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="18px"
                        height="18px"
                        viewBox="0 0 24 24"
                        fill="none"
                      >
                        <path
                          d="M7.29417 12.9577L10.5048 16.1681L17.6729 9"
                          stroke="#ffffff"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <circle
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="#ffffff"
                          strokeWidth="2"
                        />
                      </svg>
                    ) : (
                      <svg
                        width="18px"
                        height="18px"
                        viewBox="0 0 24 24"
                        version="1.1"
                      >
                        <title>ic_fluent_copy_24_regular</title>
                        <desc>Created with Sketch.</desc>
                        <g
                          id="🔍-Product-Icons"
                          stroke="none"
                          strokeWidth="1"
                          fill="none"
                          fillRule="evenodd"
                        >
                          <g
                            id="ic_fluent_copy_24_regular"
                            fill="#212121"
                            fillRule="nonzero"
                          >
                            <path
                              d="M5.50280381,4.62704038 L5.5,6.75 L5.5,17.2542087 C5.5,19.0491342 6.95507456,20.5042087 8.75,20.5042087 L17.3662868,20.5044622 C17.057338,21.3782241 16.2239751,22.0042087 15.2444057,22.0042087 L8.75,22.0042087 C6.12664744,22.0042087 4,19.8775613 4,17.2542087 L4,6.75 C4,5.76928848 4.62744523,4.93512464 5.50280381,4.62704038 Z M17.75,2 C18.9926407,2 20,3.00735931 20,4.25 L20,17.25 C20,18.4926407 18.9926407,19.5 17.75,19.5 L8.75,19.5 C7.50735931,19.5 6.5,18.4926407 6.5,17.25 L6.5,4.25 C6.5,3.00735931 7.50735931,2 8.75,2 L17.75,2 Z M17.75,3.5 L8.75,3.5 C8.33578644,3.5 8,3.83578644 8,4.25 L8,17.25 C8,17.6642136 8.33578644,18 8.75,18 L17.75,18 C18.1642136,18 18.5,17.6642136 18.5,17.25 L18.5,4.25 C18.5,3.83578644 18.1642136,3.5 17.75,3.5 Z"
                              id="🎨-Color"
                            ></path>
                          </g>
                        </g>
                      </svg>
                    )}
                    <span className={`ml-5 ${isCopyText && "white"}`}>
                      {isCopyText ? "Copied!" : "Copy to clipboard"}
                    </span>
                  </button>

                  {/* Add the Excel export link */}
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      if (!isExporting && combinedResponses.length > 0) {
                        exportToExcel();
                      }
                    }}
                    className="export-link ml-3"
                    style={{
                      color: "#0066cc",
                      textDecoration: "none",
                      cursor:
                        combinedResponses.length === 0 || isExporting
                          ? "not-allowed"
                          : "pointer",
                      opacity:
                        combinedResponses.length === 0 || isExporting ? 0.6 : 1,
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    {isExporting ? (
                      <span>Exporting...</span>
                    ) : (
                      <>
                        <svg
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                          style={{ marginRight: "4px" }}
                        >
                          <path
                            d="M13.5 3H9.6C8.43 3 7.845 3 7.4225 3.22525C7.035 3.42375 6.7275 3.729 6.528 4.1175C6.3 4.5375 6.3 5.124 6.3 6.3V17.7C6.3 18.876 6.3 19.4625 6.528 19.8825C6.7275 20.271 7.035 20.577 7.4225 20.775C7.845 21 8.43 21 9.6 21H14.4C15.57 21 16.155 21 16.5775 20.775C16.965 20.577 17.273 20.271 17.472 19.8825C17.7 19.4625 17.7 18.876 17.7 17.7V7.2M13.5 3L17.7 7.2M13.5 3V5.4C13.5 6.18 13.5 6.57 13.6545 6.864C13.79 7.124 14.0155 7.3485 14.274 7.485C14.568 7.65 14.98 7.65 15.8 7.65H17.7"
                            stroke="#0066CC"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                          <path
                            d="M12 15L16.5 15"
                            stroke="#0066CC"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                          />
                          <path
                            d="M12 11.5L16.5 11.5"
                            stroke="#0066CC"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                          />
                          <path
                            d="M12 8L13.5 8"
                            stroke="#0066CC"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                          />
                        </svg>
                        Download data
                      </>
                    )}
                  </a>

                  {/* Spacer that pushes the indicator to the right */}
                  <div style={{ flexGrow: 1 }}></div>

                  {/* Your existing Generated/Existing indicator */}
                  {combinedResponses[currentIndex]?.generated ? (
                    <span
                      className="generated-indicator"
                      title="Generated Content"
                    >
                      Generated
                    </span>
                  ) : (
                    combinedResponses[currentIndex] && (
                      <span
                        className="existing-indicator"
                        title="Existing Content"
                      >
                        Existing
                      </span>
                    )
                  )}
                </div>
                <span className="pos-relative">
                  <div
                    className="textarea-full-height"
                    style={{
                      minHeight: "500px", // minimum height
                      height: "auto",
                      width: "100%",
                      padding: "10px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      fontFamily: "inherit",
                      fontSize: "inherit",
                      whiteSpace: "pre-wrap", // keeps line breaks
                      overflowY: "auto", // vertical scrollbar
                      overflowX: "auto", // horizontal scrollbar if needed
                      boxSizing: "border-box", // ensures padding doesn't exceed width
                    }}
                    dangerouslySetInnerHTML={{
                      __html: combinedResponses[currentIndex]?.pitch || "",
                    }}
                  ></div>
                  <Modal
                    show={openModals["modal-output-2"]}
                    closeModal={() => handleModalClose("modal-output-2")}
                    buttonLabel="Ok"
                  >
                    <label>Output </label>

                    <pre
                      className="textarea-full-height"
                      // style={{
                      //   height: "800px", // set a fixed height for scrolling
                      //   width: "100%",
                      //   padding: "10px",
                      //   border: "1px solid #ccc",
                      //   borderRadius: "4px",
                      //   fontFamily: "inherit",
                      //   fontSize: "inherit",
                      //   whiteSpace: "pre-wrap", // keeps line breaks
                      //   overflowY: "auto", // vertical scrollbar
                      //   overflowX: "auto", // horizontal scrollbar if needed
                      //   boxSizing: "border-box", // ensures padding doesn't exceed width
                      // }}
                      dangerouslySetInnerHTML={{
                        __html: combinedResponses[currentIndex]?.pitch || "",
                      }} // Change this line
                    ></pre>
                  </Modal>
                  <button
                    className="full-view-icon d-flex align-center justify-center"
                    onClick={() => handleModalOpen("modal-output-2")}
                  >
                    <svg width="40px" height="40px" viewBox="0 0 512 512">
                      <polyline
                        points="304 96 416 96 416 208"
                        fill="none"
                        stroke="#000000"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="32"
                      />
                      <line
                        x1="405.77"
                        y1="106.2"
                        x2="111.98"
                        y2="400.02"
                        fill="none"
                        stroke="#000000"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="32"
                      />
                      <polyline
                        points="208 416 96 416 96 304"
                        fill="none"
                        stroke="#000000"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="32"
                      />
                    </svg>
                  </button>
                </span>{" "}
                <div className="d-flex justify-center mt-4"></div>{" "}
                {/* Add this div for navigation buttons */}
              </div>
            </>
          )}
          {tab2 === "Current prompt" && userRole === "ADMIN" && (
            <>
              <div className="tabs secondary d-flex align-center ">
                <ul className="d-flex full-width flex-wrap-991">
                  <li className="flex-50percent-991 flex-full-640">
                    <button
                      onClick={tabHandler3}
                      className={`button full-width ${
                        tab3 === "Current prompt" ? "active" : ""
                      }`}
                    >
                      Current prompt
                    </button>
                  </li>
                  <li className="flex-50percent-991 flex-full-640">
                    <button
                      onClick={tabHandler3}
                      className={`button full-width ${
                        tab3 ===
                        `Search results for "${
                          allSearchTermBodies[currentIndex] || "N/A"
                        }"`
                          ? "active"
                          : ""
                      }`}
                    >
                      Search results for "
                      {allSearchTermBodies[currentIndex] || "N/A"}"
                    </button>
                  </li>
                  <li className="flex-50percent-991 flex-full-640">
                    <button
                      onClick={tabHandler3}
                      className={`button full-width ${
                        tab3 === "All sourced data" ? "active" : ""
                      }`}
                    >
                      All sourced data
                    </button>
                  </li>
                  <li className="flex-50percent-991 flex-full-640">
                    <button
                      onClick={tabHandler3}
                      className={`button full-width ${
                        tab3 === "Sourced data summary" ? "active" : ""
                      }`}
                    >
                      Sourced data summary
                    </button>
                  </li>
                </ul>
              </div>
              {tab3 === "Current prompt" && (
                <div className="form-group">
                  <div className="d-flex mb-10"></div>
                  <span className="pos-relative">
                    <div
                      className="textarea-full-height"
                      style={{
                        height: "800px", // set a fixed height for scrolling
                        width: "100%",
                        padding: "10px",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        fontFamily: "inherit",
                        fontSize: "inherit",
                        whiteSpace: "pre-wrap", // keeps line breaks
                        overflowY: "auto", // vertical scrollbar
                        overflowX: "auto", // horizontal scrollbar if needed
                        boxSizing: "border-box", // ensures padding doesn't exceed width
                      }}
                      dangerouslySetInnerHTML={{
                        __html: allprompt[currentIndex] || "",
                      }}
                    ></div>

                    <Modal
                      show={openModals["modal-output-3"]}
                      closeModal={() => handleModalClose("modal-output-3")}
                      buttonLabel="Ok"
                    >
                      <label>Current prompt</label>

                      <pre
                        className="textarea-full-height"
                        dangerouslySetInnerHTML={{
                          __html: allprompt[currentIndex] || "",
                        }}
                      ></pre>
                    </Modal>
                    <button
                      className="full-view-icon d-flex align-center justify-center"
                      onClick={() => handleModalOpen("modal-output-3")}
                    >
                      <svg width="40px" height="40px" viewBox="0 0 512 512">
                        <polyline
                          points="304 96 416 96 416 208"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <line
                          x1="405.77"
                          y1="106.2"
                          x2="111.98"
                          y2="400.02"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <polyline
                          points="208 416 96 416 96 304"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                      </svg>
                    </button>
                  </span>
                </div>
              )}

              {tab3 ===
                `Search results for "${
                  allSearchTermBodies[currentIndex] || "N/A"
                }"` && (
                <div className="form-group">
                  <h3>
                    Search results for "
                    {allSearchTermBodies[currentIndex] || "N/A"}"
                  </h3>
                  <span className="pos-relative">
                    <div
                      className="textarea-full-height"
                      style={{
                        height: "800px",
                        width: "100%",
                        padding: "10px",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        fontFamily: "inherit",
                        fontSize: "inherit",
                        whiteSpace: "pre-wrap",
                        overflowY: "auto",
                        overflowX: "auto",
                        boxSizing: "border-box",
                      }}
                    >
                      <ul>
                        {allsearchResults[currentIndex]?.map(
                          (result: string, index: number) => (
                            <li key={index}>
                              <a
                                href={result}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                {result}
                              </a>
                            </li>
                          )
                        )}
                      </ul>
                    </div>

                    <Modal
                      show={openModals["modal-output-search"]}
                      closeModal={() => handleModalClose("modal-output-search")}
                      buttonLabel="Ok"
                    >
                      <label>
                        Search results for "
                        {allSearchTermBodies[currentIndex] || "N/A"}"
                      </label>
                      <pre
                        className="textarea-full-height"
                        // style={{
                        //   height: "800px",
                        //   width: "100%",
                        //   padding: "10px",
                        //   border: "1px solid #ccc",
                        //   borderRadius: "4px",
                        //   fontFamily: "inherit",
                        //   fontSize: "inherit",
                        //   whiteSpace: "pre-wrap",
                        //   overflowY: "auto",
                        //   overflowX: "auto",
                        //   boxSizing: "border-box",
                        // }}
                      >
                        <ul>
                          {allsearchResults[currentIndex]?.map(
                            (result: string, index: number) => (
                              <li key={index}>
                                <a
                                  href={result}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  {result}
                                </a>
                              </li>
                            )
                          )}
                        </ul>
                      </pre>
                    </Modal>
                    <button
                      className="full-view-icon d-flex align-center justify-center"
                      onClick={() => handleModalOpen("modal-output-search")}
                    >
                      <svg width="40px" height="40px" viewBox="0 0 512 512">
                        <polyline
                          points="304 96 416 96 416 208"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <line
                          x1="405.77"
                          y1="106.2"
                          x2="111.98"
                          y2="400.02"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <polyline
                          points="208 416 96 416 96 304"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                      </svg>
                    </button>
                  </span>
                </div>
              )}

              {tab3 === "All sourced data" && (
                <div className="form-group">
                  <h3>All sourced data</h3>
                  <span className="pos-relative">
                    <div
                      className="textarea-full-height"
                      style={{
                        height: "800px",
                        width: "100%",
                        padding: "10px",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        fontFamily: "inherit",
                        fontSize: "inherit",
                        whiteSpace: "pre-wrap",
                        overflowY: "auto",
                        overflowX: "auto",
                        boxSizing: "border-box",
                      }}
                    >
                      <p>{everyscrapedData[currentIndex] || ""}</p>
                    </div>

                    <Modal
                      show={openModals["modal-output-scraped"]}
                      closeModal={() =>
                        handleModalClose("modal-output-scraped")
                      }
                      buttonLabel="Ok"
                    >
                      <label>All sourced data</label>
                      <pre
                        className="textarea-full-height"
                        // style={{
                        //   height: "800px",
                        //   width: "100%",
                        //   padding: "10px",
                        //   border: "1px solid #ccc",
                        //   borderRadius: "4px",
                        //   fontFamily: "inherit",
                        //   fontSize: "inherit",
                        //   whiteSpace: "pre-wrap",
                        //   overflowY: "auto",
                        //   overflowX: "auto",
                        //   boxSizing: "border-box",
                        // }}
                      >
                        <p>{everyscrapedData[currentIndex] || ""}</p>
                      </pre>
                    </Modal>
                    <button
                      className="full-view-icon d-flex align-center justify-center"
                      onClick={() => handleModalOpen("modal-output-scraped")}
                    >
                      <svg width="40px" height="40px" viewBox="0 0 512 512">
                        <polyline
                          points="304 96 416 96 416 208"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <line
                          x1="405.77"
                          y1="106.2"
                          x2="111.98"
                          y2="400.02"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <polyline
                          points="208 416 96 416 96 304"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                      </svg>
                    </button>
                  </span>
                </div>
              )}

              {tab3 === "Sourced data summary" && (
                <div className="form-group">
                  <h3>Sourced data summary</h3>
                  <span className="pos-relative">
                    <div
                      className="textarea-full-height"
                      style={{
                        height: "800px",
                        width: "100%",
                        padding: "10px",
                        border: "1px solid #ccc",
                        borderRadius: "4px",
                        fontFamily: "inherit",
                        fontSize: "inherit",
                        whiteSpace: "pre-wrap",
                        overflowY: "auto",
                        overflowX: "auto",
                        boxSizing: "border-box",
                      }}
                    >
                      <p>
                        {allsummery[currentIndex] || "No summary available"}
                      </p>
                    </div>

                    <Modal
                      show={openModals["modal-output-summary"]}
                      closeModal={() =>
                        handleModalClose("modal-output-summary")
                      }
                      buttonLabel="Ok"
                    >
                      <label>Sourced data summary</label>
                      <pre
                        className="textarea-full-height"
                        // style={{
                        //   height: "800px",
                        //   width: "100%",
                        //   padding: "10px",
                        //   border: "1px solid #ccc",
                        //   borderRadius: "4px",
                        //   fontFamily: "inherit",
                        //   fontSize: "inherit",
                        //   whiteSpace: "pre-wrap",
                        //   overflowY: "auto",
                        //   overflowX: "auto",
                        //   boxSizing: "border-box",
                        // }}
                      >
                        <p>
                          {allsummery[currentIndex] || "No summary available"}
                        </p>
                      </pre>
                    </Modal>
                    <button
                      className="full-view-icon d-flex align-center justify-center"
                      onClick={() => handleModalOpen("modal-output-summary")}
                    >
                      <svg width="40px" height="40px" viewBox="0 0 512 512">
                        <polyline
                          points="304 96 416 96 416 208"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <line
                          x1="405.77"
                          y1="106.2"
                          x2="111.98"
                          y2="400.02"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                        <polyline
                          points="208 416 96 416 96 304"
                          fill="none"
                          stroke="#000000"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="32"
                        />
                      </svg>
                    </button>
                  </span>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
};

export default Output;
