import React, { useState, useEffect } from "react";
import Modal from "../common/Modal";
import API_BASE_URL from "../../config";
import { useModel } from "../../ModelContext";
import DatePicker from "react-datepicker";
import moment from "moment-timezone";
import "react-datepicker/dist/react-datepicker.css";
import { stringify } from "ajv";
import TimePicker from 'react-time-picker';
import { differenceInMinutes, differenceInHours, differenceInDays } from "date-fns";

interface SettingsProps {
  selectedClient: string;
  fetchClientSettings: (clientID: number) => Promise<any>;
  settingsForm: any;
  settingsFormHandler: (e: React.ChangeEvent<HTMLInputElement>) => void;
  settingsFormOnSubmit: (e: any) => void;
}


interface SettingInterface {
  settingsForm: any;
  searchTermForm: any;
  settingsFormHandler: (value: any) => void;
  searchTermFormHandler: (value: any) => void;
  settingsFormOnSubmit: (e: any) => void;
  searchTermFormOnSubmit: (e: any) => void;
}



interface Model {
  id: number;
  modelName: string;
  inputPrice: number;
  outputPrice: number;
}

interface ClientSettings {
  modelName: string;
  searchCount: string;
  searchTerm: string;
  instructions: string;
  systemInstructions: string;
  emailTemplate: string;
}
interface UpdateSettingsPayload {
  model_name: string;
  search_URL_count: string;
  search_term: string;
  instruction: string;
  system_instruction: string;
}

interface SearchTermForm {
  searchCount: string;
  searchTerm: string;
  instructions: string;
  output?: string;
  [key: string]: any; // For any additional properties
}

interface SettingsForm {
  systemInstructions: string;
  emailTemplate?: string;
  [key: string]: any; // For any additional properties
}

type FormEventType = {
  target: {
    name: string;
    value: string;
  };
};

const Mail: React.FC<SettingInterface & SettingsProps > = ({
  settingsForm,
  searchTermForm,
  searchTermFormHandler,
  settingsFormHandler,
  settingsFormOnSubmit,
  searchTermFormOnSubmit,
  selectedClient, 
  fetchClientSettings, 
  
}) => {
  const [openModals, setOpenModals] = useState<{ [key: string]: boolean }>({});
  const { setSelectedModelName } = useModel(); // Destructure setSelectedModelName from context

  const [models, setModels] = useState<Model[]>([]);

  // Added state for selected model
  const [selectedModel, setSelectedModel] = useState<string>("");

  useEffect(() => {
    const fetchModels = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/auth/modelsinfo`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data: Model[] = await response.json();
        setModels(data);
      } catch (error) {
        console.error("Error fetching models:", error);
      }
    };

    fetchModels();
  }, []); // Empty dependency array ensures this runs once on component mount

  // Load selected model from localStorage on mount
  useEffect(() => {
    const savedModel = localStorage.getItem("selectedModel");
    if (savedModel) {
      setSelectedModel(savedModel);
      setSelectedModelName(savedModel); // Update context as well
    }
  }, []);

  const [settingsData, setSettingsData] = useState({
    Model_name: "",
    Search_URL_count: "",
    Search_term:"",
    Instruction:"",
    System_instruction:"",

    // ... other settings
  });


  const [localSettingsForm, setLocalSettingsForm] = useState<SettingsForm>({
    systemInstructions: '',
    emailTemplate: ''
  });
  
  const [localSearchTermForm, setLocalSearchTermForm] = useState<SearchTermForm>({
    searchCount: '',
    searchTerm: '',
    instructions: '',
    output: ''
  });

  // CHANGE THIS useEffect
  useEffect(() => {
    const loadClientSettings = async () => {
      if (selectedClient) {
        try {
          const settings = await fetchClientSettings(Number(selectedClient));
          console.log("Full settings object:", settings);
  
          if (settings) {
            // Update model selection
            setSelectedModel(settings.modelName || "");
  
            // First update local state
            setLocalSearchTermForm(prev => ({
              ...prev,
              searchCount: settings.searchCount?.toString() || "",
              searchTerm: settings.searchTerm || "",
              instructions: settings.instructions || ""
            }));
  
            // Then update parent form state
            searchTermFormHandler({
              target: {
                name: 'searchCount',
                value: settings.searchCount?.toString() || ""
              }
            } as any);
  
            searchTermFormHandler({
              target: {
                name: 'searchTerm',
                value: settings.searchTerm || ""
              }
            } as any);
  
            searchTermFormHandler({
              target: {
                name: 'instructions',
                value: settings.instructions || ""
              }
            } as any);
  
            // Update settings form
            settingsFormHandler({
              target: {
                name: 'systemInstructions',
                value: settings.systemInstructions || ""
              }
            } as any);
  
            // Log for debugging
            console.log('Updated form values:', {
              searchCount: settings.searchCount,
              searchTerm: settings.searchTerm
            });
          }
        } catch (error) {
          console.error('Error loading client settings:', error);
        }
      }
    };
  
    loadClientSettings();
  }, [selectedClient]);

    // Modify handleModelChange to update local state
    const handleModelChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
      const modelName = event.target.value;
      setSelectedModel(modelName);
      setSelectedModelName(modelName);
      localStorage.setItem("selectedModel", modelName);
      // Specify the type for prev
      setLocalSettingsForm((prev: SettingsForm) => ({ ...prev, model: modelName }));
      settingsFormHandler(event); // Call the original handler if needed
    }

  const handleModalClose = (id: string) => {
    setOpenModals((prev) => ({ ...prev, [id]: false }));
  };
  const handleModalOpen = (id: string) => {
    setOpenModals((prev) => ({ ...prev, [id]: true }));
  };
  
  useEffect(() => {
  // Initialize local state with the props when they change
  setLocalSettingsForm(settingsForm);
  setLocalSearchTermForm(searchTermForm);
}, [settingsForm, searchTermForm]);

interface SettingsForm {
  [key: string]: string; // Assuming all values are strings
}

interface SearchTermForm {
  [key: string]: string; // Assuming all values are strings
}

const handleSettingsFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const { name, value } = e.target;
  setLocalSettingsForm((prev: SettingsForm) => ({ ...prev, [name]: value }));
  settingsFormHandler(e); // Call the original handler
};

const handleSearchTermFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const { name, value } = e.target;
  setLocalSearchTermForm((prev: SearchTermForm) => ({ ...prev, [name]: value }));
  searchTermFormHandler(e); // Call the original handler
};

const handleUpdateSettings = async () => {
  try {
    const settingsData = {
      model_name: selectedModel,
      search_URL_count: parseInt(searchTermForm.searchCount) || 0,
      search_term: searchTermForm.searchTerm || "",
      instruction: searchTermForm.instructions || "",
      system_instruction: settingsForm.systemInstructions || ""
    };

    console.log('Sending update with:', settingsData);

    const response = await fetch(`${API_BASE_URL}/api/auth/updateClientSettings/${selectedClient}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(settingsData),
    });

    if (!response.ok) {
      throw new Error(`Failed to update settings: ${response.statusText}`);
    }

    alert("Settings updated successfully");
    
    // Refresh settings
    const updatedSettings = await fetchClientSettings(Number(selectedClient));
    if (updatedSettings) {
      setSelectedModel(updatedSettings.modelName || "");
      searchTermFormHandler({
        target: {
          name: 'searchCount',
          value: updatedSettings.searchCount?.toString() || ""
        }
      });
      searchTermFormHandler({
        target: {
          name: 'searchTerm',
          value: updatedSettings.searchTerm || ""
        }
      });
    }
  } catch (error) {
    console.error('Error updating settings:', error);
    alert();
  }
};

useEffect(() => {
  console.log('Form Values Updated:', {
    searchTermForm,
    localSearchTermForm,
    selectedModel
  });
}, [searchTermForm, localSearchTermForm, selectedModel]);

const [smtpViewForm, setSMTPViewForm] = useState({
  Server: '',
  Port: '',
  Username: '',
  Password: '',
  useSsl:''
});

const onSMTPViewInput = (e: React.ChangeEvent<HTMLInputElement>) => {
  const { name, value } = e.target;
  setSMTPViewForm(prev => ({
    ...prev,
    [name]: value
  }));
};

const handleAddSMTPView = async () => {
  if (!smtpViewForm.Server || !smtpViewForm.Port || !smtpViewForm.Username || !smtpViewForm.Password || !smtpViewForm.useSsl || !selectedClient) {
    alert('Please fill all fields and ensure a client is selected');
    return;
  }
  const sanitizedForm = {
    ...smtpViewForm,
    Port: parseInt(smtpViewForm.Port, 10) || 0,  // Default to 0 if invalid
    useSsl: Boolean(smtpViewForm.useSsl)         // Ensure strict boolean
  };  
  await addSMTPView(smtpViewForm.Server, parseInt(smtpViewForm.Port), smtpViewForm.Username, smtpViewForm.Password, Boolean(smtpViewForm.useSsl),selectedClient);  
};

//smtp delete
const handleDeleteSMTPView = async () => {
  if (!smtpViewForm.Server || !selectedClient || !smtpViewForm.Port || !smtpViewForm.Username || !smtpViewForm.Password || !smtpViewForm.useSsl) {
    alert('Please enter mail configuration and ensure a client is selected');
    return;
  }

  await deleteSMTPView(smtpViewForm.Server,smtpViewForm.Port,smtpViewForm.Username,smtpViewForm.Password,Boolean(smtpViewForm.useSsl), selectedClient);  
    setSMTPViewForm({
      Server: '',
      Port: '',
      Username: '',
      Password: '',
      useSsl:''
    });
}

const addSMTPView = async (Server: string, Port: number, Username: string, Password: string, useSsl: Boolean, clientId: string) => {
 debugger;
  try {
    const response = await fetch(`${API_BASE_URL}/api/sequence-email/save`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiZGFuaXNoIiwiVXNlcklkIjoiNjI2IiwiVXNlclJvbGUiOiIyIiwiZXhwIjoxNzQ2MDE3MTExLCJpc3MiOiJQaXRjaEdlbkFwaSIsImF1ZCI6IlBpdGNoR2VuQ2xpZW50cyJ9.icijYfXuaBBwlta6Z9EUWOHvmLjlEijGdBKGjM9kNFY` 
      },
      body: JSON.stringify({
        Server,
        Port,
        Username,
        Password,
        useSsl,
        clientId: parseInt(clientId)
      })
    });
    if (!response.ok) {
      throw new Error('Failed to add smtp view');
    }
    const data = await response.json();
    alert('SMTP view added successfully');
    return data;
  } catch (error) {
    debugger;
    console.error('Error adding SMTP view:', error);
    alert('Failed to add SMTP view');
  }
};

const deleteSMTPView = async (Server: string, Port: string, Username: string, Password: string, useSSL:boolean, clientId: string) => {
  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/deletesmtpview`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      }
    });

    if (!response.ok) {
      throw new Error('Failed to delete SMTP view');
    }

    alert('SMTP view deleted successfully');
  } catch (error) {
    console.error('Error deleting SMTP view:', error);
    alert('Failed to delete SMTP view');
  }
};

const [isLoading, setIsLoading] = useState(false);

const [formData, setFormData] = useState({
  Title: '',
  Steps:'',
  DelayInDays:'',
  ScheduleDate:'',
  ScheduleTime: '',
  TimeZone:''
});
const [response, setResponse] = useState(null);

const handleChange = (e:any) => {
  setFormData({
    ...formData,
    [e.target.name]: e.target.value
  });
};

const [selectedDate, setSelectedDate] = useState<Date | null>(null);
const [diffResult, setDiffResult] = useState("");

const calculateDifference = (date:any) => {
  const now = moment(); // current time
  const selected = moment(date); // selected time

  const diffInMinutes = selected.diff(now, "minutes");
  const diffInHours = selected.diff(now, "hours");
  const diffInDays = selected.diff(now, "days");

  // Build display text
  const resultText = `
    Difference: ${Math.abs(diffInDays)} day(s), 
    ${Math.abs(diffInHours % 24)} hour(s), 
    ${Math.abs(diffInMinutes % 60)} minute(s) 
    (${diffInMinutes > 0 ? "in future" : "ago"})
  `;

  setDiffResult(resultText);
};


const handleSubmit = async (e:any) => {
  e.preventDefault();
  debugger;
  const localTime = moment(datetime).tz(timezone);
  const utcTime = localTime.clone().utc();
  debugger;

  // Extract date and time separately
  const localDate = localTime.format('YYYY-MM-DD');
  const localTimeOnly = localTime.format('HH:mm');
  const utcDate = utcTime.format('YYYY-MM-DD');
  const utcTimeOnly = utcTime.format('HH:mm');
  const scheduleDateTimeUTC = utcTime.format(); // ISO string
  
  const Datenow = new Date();

  console.log("Current date", Datenow);
  console.log("Local Date:", localDate);
  console.log("Local Time:", localTimeOnly);
  console.log("UTC Date:", utcDate);
  console.log("UTC Time:", utcTimeOnly);

  console.log("Title:", formData.Title);
  console.log("Scheduled (local):", localTime.format());
  console.log("Scheduled (UTC):", utcTime.format());
  debugger;

  const payload = {
    ...formData,
    ScheduleDate: utcDate,
    ScheduleTime:utcTimeOnly,
    TimeZone: timezone
  };

  try {
      const response = await fetch(`${API_BASE_URL}/api/sequence-email/create-sequence`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiZGFuaXNoIiwiVXNlcklkIjoiNjI2IiwiVXNlclJvbGUiOiIyIiwiZXhwIjoxNzQ2MDE3MTExLCJpc3MiOiJQaXRjaEdlbkFwaSIsImF1ZCI6IlBpdGNoR2VuQ2xpZW50cyJ9.icijYfXuaBBwlta6Z9EUWOHvmLjlEijGdBKGjM9kNFY` 
      },
      body: JSON.stringify(payload)
    });
    debugger;
    const data = await response.json();
    setResponse(data);
  debugger;

  } catch (error) {
    console.error('Error:', error);
    //setResponse({ success: false, message: 'Submission failed.' });
  }
};
const timezoneOptions = [
  { label: "United States (New York)", value: "America/New_York" },
  { label: "United Kingdom (London)", value: "Europe/London" },
  { label: "India (Kolkata)", value: "Asia/Kolkata" },
  { label: "Australia (Sydney)", value: "Australia/Sydney" },
];

const [datetime, setDatetime] = useState<Date | null>(new Date());
const [timezone, setTimezone] = useState("Asia/Kolkata");

//Mahesh Delays in Days start
{/*// const [title, setTitle] = useState('');
//   const [steps, setSteps] = useState([
//     { delayInDays: 0, sendTime: { ticks: 0 } }
//   ]);

//   const handleStepChange = (index:any, field:any, value:any) => {
//     const newSteps = [...steps];
//     if (field === 'delayInDays') {
//       newSteps[index].delayInDays = parseInt(value, 10);
//     } else if (field === 'ticks') {
//       newSteps[index].sendTime.ticks = parseInt(value, 10);
//     }
//     setSteps(newSteps);
//   };
//   const addStep = () => {
//     setSteps([...steps, { delayInDays: 0, sendTime: { ticks: 0 } }]);
//   };
//   const removeStep = (index:any) => {
//     const newSteps = [...steps];
//     newSteps.splice(index, 1);
//     setSteps(newSteps);
//   };
//   const handleSubmit = (e:any) => {
//     e.preventDefault();

//     const payload = {
//       title,
//       steps
//     };
//     console.log('Submitting:', payload);
//     //fetch('https://api.example.com/sequence', {
//       fetch(`${API_BASE_URL}/api/sequence-email/create-sequence`, { 
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json'
//       },
//       body: JSON.stringify(payload)
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then(data => {
//         console.log('Success:', data);
//         alert('Sequence submitted successfully!');
//       })
//       .catch(error => {
//         console.error('Error:', error);
//         alert('Failed to submit sequence');
//       });
//     };*/}
// Mahesh Delays in Days end

//New Mahesh Code time picker start
{/*const [title, setTitle] = useState('');
const [steps, setSteps] = useState([
  { delayInDays: 0, sendTime: { ticks: 0, timeValue: '00:00' } }
]);

const TICKS_PER_SECOND = 10_000_000;  
const handleStepChange = (index:any, field:any, value:any) => {
  const newSteps = [...steps];
  if (field === 'delayInDays') {
    newSteps[index].delayInDays = parseInt(value, 10);
  } else if (field === 'timeValue') {
    // Save the time string (like '14:30') into timeValue
    newSteps[index].sendTime.timeValue = value;

    // Convert HH:mm to ticks (since midnight)
    const [hours, minutes] = value.split(':').map(Number);
    const totalSeconds = hours * 3600 + minutes * 60;
    const ticks = totalSeconds * TICKS_PER_SECOND;
    newSteps[index].sendTime.ticks = ticks;
  }
  setSteps(newSteps);
};
const addStep = () => {
  setSteps([...steps, { delayInDays: 0, sendTime: { ticks: 0, timeValue: '00:00' } }]);
};
const removeStep = (index:any) => {
  const newSteps = [...steps];
  newSteps.splice(index, 1);
  setSteps(newSteps);
};

const handleSubmit = (e:any) => {
  e.preventDefault();

  const payload = {
    title,
    steps: steps.map(step => ({
      delayInDays: step.delayInDays,
      sendTime: { ticks: step.sendTime.ticks }
    }))
  };
  console.log('Submitting:', payload);
debugger;
  fetch(`${API_BASE_URL}/api/sequence-email/create-sequence`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
      alert('Sequence submitted successfully!');
    })
    .catch(error => {
      debugger;
      console.error('Error:', error);
      alert('Failed to submit sequence');
    });
};*/}
//New Mahesh Code time picker End


const [tab, setTab] = useState("Configuration");
const tabHandler = (e: React.ChangeEvent<any>) => {
  const { innerText } = e.target;
  console.log(innerText, "innerText");
  setTab(innerText);
};

return (
    <div className="login-box gap-down">
      <div className="form-group d-flex justify-between"></div>
      <div className="tabs secondary d-flex align-center">
          <ul className="d-flex">
            <li>
              <button
                onClick={tabHandler}
                className={`button ${tab === "Configuration" ? "active" : ""}`}
              >
                Configuration
              </button>
            </li>
            <li>
              <button
                onClick={tabHandler}
                className={`button ${tab === "Shedule" ? "active" : ""}`}
              >
                Shedule
              </button>
            </li>
            <li>
              <button
                onClick={tabHandler}
                className={`button ${tab === "Dashboard" ? "active" : ""}`}
              >
                Dashboard
              </button>
            </li>
          </ul>
        </div>

        {/* New Tab */}
        {tab === "Configuration" && (
          <>
            <div className="tabs secondary d-flex align-center">
              <div className="input-section edit-section">
                <div className="row">
                  <div className="col col-4">
                      <div className="form-group">
                        <label>Server</label>
                        <input
                          type="text"
                          value={smtpViewForm.Server}
                          name="Server"
                          placeholder="Enter Server"
                          onChange={onSMTPViewInput}
                        />
                      </div>
                      <div className="form-group">
                        <label>Port</label>
                        <input
                          type="text"
                          value={smtpViewForm.Port}
                          name="Port"
                          placeholder="Enter Port"
                          onChange={onSMTPViewInput}
                        />
                    </div>
                      <div className="form-group">
                        <label>Username</label>
                        <input
                          type="text"
                          value={smtpViewForm.Username}
                          name="Username"
                          placeholder="Enter Username"
                          onChange={onSMTPViewInput}
                        />
                    </div>
                      <div className="form-group">
                        <label>Password</label>
                        <input
                          type="Password"
                          value={smtpViewForm.Password}
                          name="Password"
                          placeholder="Enter Password"
                          onChange={onSMTPViewInput}
                        />
                    </div>          
                      <div className="form-group">
                        <label>useSsl</label>
                        <input
                          type="text"                        
                          value={smtpViewForm.useSsl}
                          name="useSsl"
                          placeholder="Enter SSL"
                          onChange={onSMTPViewInput}
                        />
                      </div>
                    </div>

                    <div className="col col-4">
                      <div className="form-group d-flex" style={{ marginTop: "24px" }}>
                        <button
                          className="save-button button small d-flex justify-between align-center"
                          onClick={handleAddSMTPView}
                          disabled={isLoading}
                        >
                          {isLoading ? (
                            <span>Adding...</span>
                          ) : (
                            <>
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="#FFFFFF"
                                viewBox="0 0 30 30"
                                width="22px"
                                height="22px"
                              >
                                <path d="M15,3C8.373,3,3,8.373,3,15c0,6.627,5.373,12,12,12s12-5.373,12-12C27,8.373,21.627,3,15,3z M21,16h-5v5 c0,0.553-0.448,1-1,1s-1-0.447-1-1v-5H9c-0.552,0-1-0.447-1-1s0.448-1,1-1h5V9c0-0.553,0.448-1,1-1s1,0.447,1,1v5h5 c0.552,0,1,0.447,1,1S21.552,16,21,16z" />
                              </svg>
                              <span className="ml-5">Add</span>
                            </>
                          )}
                        </button>

                        <button
                          className="secondary button small d-flex justify-between align-center ml-10"
                          onClick={handleDeleteSMTPView}
                          disabled={isLoading}
                        >
                          {isLoading ? (
                            <span>Deleting...</span>
                          ) : (
                            <>
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="#FFFFFF"
                                viewBox="0 0 50 50"
                                width="18px"
                                height="18px"
                              >
                                <path d="M 21 2 C 19.354545 2 18 3.3545455 18 5 L 18 7 L 8 7 A 1.0001 1.0001 0 1 0 8 9 L 9 9 L 9 45 C 9 46.654 10.346 48 12 48 L 38 48 C 39.654 48 41 46.654 41 45 L 41 9 L 42 9 A 1.0001 1.0001 0 1 0 42 7 L 32 7 L 32 5 C 32 3.3545455 30.645455 2 29 2 L 21 2 z" />
                              </svg>
                              <span className="ml-5">Delete</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>

                {/* ... rest of the code ... */}
                <div className="login-box gap-down d-flex">
                  {/* ... other JSX */}

                  <button
                    type="button"
                    onClick={handleUpdateSettings}
                    className="save-button button full"
                  >
                    Update Settings {/* Or "Save Settings" */}
                  </button>

                  {/* ... rest of your JSX */}
                </div>         
              </div>
            </div>
            </>
        )}

        {tab === "Shedule" && (
          <div className="tabs secondary d-flex align-center">
              <div className="input-section edit-section">
  
                <form onSubmit={handleSubmit} className="space-y-4">
                <div className="row">
                <div className="col col-4">
                    <div className="form-group">
                      <label>Title</label>
                      <input
                        type="text"
                        value={formData.Title}
                        name="Title"
                        placeholder="Enter Title"
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-group">
                      <label>Schedule</label>
                      <DatePicker
                        //selected={datetime}                       
                        //onChange={(date) => setDatetime(date)}
                        selected={selectedDate}
                        onChange={(date) => {
                          setSelectedDate(date);
                          calculateDifference(date);
                        }}
                        showTimeSelect
                        timeFormat="HH:mm"
                        timeIntervals={15}
                        dateFormat="Pp"
                        className="border p-2 w-full"
                      />
                    </div>
                    {selectedDate && (
                      <div style={{ marginTop: "20px" }}>
                        <strong>Selected date:</strong> {moment(selectedDate).format("MMMM Do YYYY, h:mm:ss A")}
                        <br />
                        <strong>{diffResult}</strong>
                      </div>
                    )}
                    <div className="form-group">
                      <label>Timezone</label>
                      <select
                        value={timezone}
                        onChange={(e) => setTimezone(e.target.value)}
                        className="border p-2 w-full"
                      >
                        {timezoneOptions.map((tz) => (
                          <option key={tz.value} value={tz.value}>
                            {tz.label}
                          </option>
                        ))}
                      </select>                    
                    </div>
                  </div>
                </div>

                  <button
                    type="submit"
                    className="save-button button full"
                  >
                    Submit
                  </button>
                </form>
              </div>                    
            </div>

    //       <form onSubmit={handleSubmit} style={{ padding: '20px', maxWidth: '600px' }}>
    //   <h2>Create Sequence</h2>

    //   <div style={{ marginBottom: '15px' }}>
    //     <label>
    //       Title:
    //       <input
    //         type="text"
    //         value={title}
    //         onChange={e => setTitle(e.target.value)}
    //         required
    //         style={{ marginLeft: '10px', padding: '5px' }}
    //       />
    //     </label>
    //   </div>

    //   <h3>Steps</h3>
    //   {steps.map((step, index) => (
    //     <div key={index} style={{ border: '1px solid #ddd', padding: '10px', marginBottom: '10px' }}>
    //       <label>
    //         Delay in Days:
    //         <input
    //           type="number"
    //           value={step.delayInDays}
    //           onChange={e => handleStepChange(index, 'delayInDays', e.target.value)}
    //           style={{ marginLeft: '10px', padding: '5px' }}
    //         />
    //       </label>

    //       <br />

    //       <label>
    //         Send Time (Ticks):
    //         <input
    //           type="number"
    //           value={step.sendTime.ticks}
    //           onChange={e => handleStepChange(index, 'ticks', e.target.value)}
    //           style={{ marginLeft: '10px', padding: '5px' }}
    //         />
    //       </label>

    //       <br />

    //       {steps.length > 1 && (
    //         <button type="button" onClick={() => removeStep(index)} style={{ marginTop: '5px', color: 'red' }}>
    //           Remove Step
    //         </button>
    //       )}
    //     </div>
    //   ))}

    //   <button type="button" onClick={addStep} style={{ marginBottom: '15px' }}>
    //     Add Step
    //   </button>
    //   <br />

    //   <button type="submit">Submit Sequence</button>
    // </form>

    



    //design new code for timepicker start
    // <div className="tabs secondary d-flex align-center">
    // <div className="input-section edit-section">
    // <form onSubmit={handleSubmit} className="space-y-4"> 
    //   <h2>Create Sequence</h2>
    //   <div className="row">
    //       <div className="col col-4">
    //           <div className="form-group">
    //           <label>Title:</label>
    //             <input
    //               type="text"
    //               value={title}
    //               onChange={e => setTitle(e.target.value)}
    //               required
    //             />
    //          </div>
    //         </div>
    //   </div>


    //   <h3>Steps</h3>
    //   {steps.map((step, index) => (
    //     <div key={index}> 
    //       <label>Delay in Days:</label><br />
    //         <input
    //           type="number"
    //           value={step.delayInDays}
    //           onChange={e => handleStepChange(index, 'delayInDays', e.target.value)}
    //         />

    //       <br /><br />

    //       <label>Send Time:</label>
    //         <TimePicker
    //           onChange={value => handleStepChange(index, 'timeValue', value)}
    //           value={step.sendTime.timeValue}
    //           disableClock={true}
    //           clearIcon={null}
    //           format="HH:mm"
    //         />
    //       <small>Ticks: {step.sendTime.ticks}</small>
    //       <br />
          
    //       {steps.length > 1 && (
    //         <button type="button" onClick={() => removeStep(index)} style={{ marginTop: '5px', color: 'red' }}>
    //           Remove Step
    //         </button>
    //       )}
    //     </div>
    //   ))}

    //   <button type="button" onClick={addStep} className="save-button button" >
    //     Add Step
    //   </button>
    //   <br />

    //   <button type="submit" className="save-button button">Submit Sequence</button>
      
    // </form>
    // </div>
    // </div>
    //design new code for timepicker end

        )}

        {tab === "Dashboard" && (
          <div className="form-group">
            <div className="d-flex">
            <h2>Dashboard</h2>            
            </div>
          </div>
        )}

    </div>
  );
};

export default Mail;
